let allProfiles=[]; let editingProfileId=null;
const list=document.getElementById('profilesList'), filter=document.getElementById('profilesFilter'), status=document.getElementById('profilesStatus');
const modal=document.getElementById('profilePageEditModal'), fields=document.getElementById('profilePageEditFields'), editStatus=document.getElementById('profilePageEditStatus');
const previewModal=document.getElementById('profilePreviewModal'), previewFields=document.getElementById('profilePreviewFields'), previewName=document.getElementById('profilePreviewName');
const editableFields=[["name","Full Name",false],["date_of_birth","Date of Birth",false],["nationality","Nationality",false],["email","Email",false],["phone_number","Phone Number",false],["document_number","Emirates ID",false],["issue_date","Issue Date",false],["expiry_date","Expiry Date",false],["education","Education",true],["skills","Skills",true],["experience","Experience",true],["projects","Projects",true]];
const safe=v=>escapeText(v||'—');
function renderProfiles(profiles){
  list.innerHTML='';
  if(!profiles.length){list.innerHTML='<div class="profiles-empty">No matching profiles found.</div>';return;}
  const canEdit=window.currentUser?.role==='authorized' && window.portalView!=='hr';
  profiles.forEach(p=>{
    const row=document.createElement('div'); row.className='profile-list-row';
    row.innerHTML=`<div class="profile-card-shell"><div><div class="profile-list-name">${safe(p.name)}</div><div class="profile-list-sub">${safe(p.nationality)}</div></div><div class="profile-card-meta"><span>EMIRATES ID</span><strong>${safe(p.document_number)}</strong></div></div><div class="profile-list-actions"><button class="profile-action-button preview" data-preview="${escapeText(p.id)}">Preview</button>${canEdit?`<button class="profile-action-button primary" data-edit="${escapeText(p.id)}">Edit</button><button class="profile-delete-icon" data-delete="${escapeText(p.id)}" title="Delete profile" aria-label="Delete profile">⌫</button>`:''}</div>`;
    list.appendChild(row);
  });
}
async function loadProfiles(){await window.authReady;try{const r=await fetch('/profiles');if(r.status===401){location.href='/app/login.html';return;}allProfiles=await r.json();renderProfiles(allProfiles);}catch(e){list.innerHTML='<div class="profiles-empty">Could not load profiles.</div>';}}
filter.addEventListener('input',()=>{const q=filter.value.trim().toLowerCase();renderProfiles(!q?allProfiles:allProfiles.filter(p=>[p.name,p.email,p.document_number,p.nationality].some(v=>(v||'').toLowerCase().includes(q))));});
function buildPreview(p){
  previewName.textContent=p.name||'Employee Profile'; previewFields.innerHTML='';
  editableFields.forEach(([key,label,large])=>{const item=document.createElement('div');item.className='preview-field'+(large?' full':'');item.innerHTML=`<span>${label}</span><div>${safe(p[key])}</div>`;previewFields.appendChild(item);});
}
async function previewProfile(id){
  previewFields.innerHTML='<div class="profiles-empty">Loading profile...</div>'; previewModal.classList.remove('hidden');
  const r=await fetch(`/profiles/${encodeURIComponent(id)}`); const p=await r.json();
  if(!r.ok){previewFields.innerHTML=`<div class="profiles-empty">${escapeText(p.detail||'Could not load profile.')}</div>`;return;} buildPreview(p);
}
function closePreview(){previewModal.classList.add('hidden');}
function buildEditFields(p){fields.innerHTML='';editableFields.forEach(([key,label,large])=>{const w=document.createElement('div');w.className='edit-field'+(large?' full':'');const c=large?document.createElement('textarea'):document.createElement('input');c.dataset.field=key;c.value=p[key]||'';w.innerHTML=`<label>${label}</label>`;w.appendChild(c);fields.appendChild(w);});}
async function editProfile(id){if(window.currentUser?.role!=='authorized')return;editingProfileId=id;editStatus.textContent='Loading profile...';modal.classList.remove('hidden');const r=await fetch(`/profiles/${encodeURIComponent(id)}`);const p=await r.json();if(!r.ok){editStatus.textContent=p.detail||'Could not load profile.';return;}buildEditFields(p);editStatus.textContent='';}
async function saveProfile(){if(window.currentUser?.role!=='authorized')return;const data={};fields.querySelectorAll('[data-field]').forEach(el=>data[el.dataset.field]=el.value.trim()||null);editStatus.textContent='Saving changes...';const r=await fetch(`/profiles/${encodeURIComponent(editingProfileId)}`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const d=await r.json();if(!r.ok){editStatus.textContent=d.detail||'Could not update profile.';return;}editStatus.textContent='Profile updated successfully.';await loadProfiles();setTimeout(()=>modal.classList.add('hidden'),650);}
async function deleteProfile(id){if(window.currentUser?.role!=='authorized')return;const p=allProfiles.find(x=>x.id===id);if(!confirm(`Delete ${p?.name||'this profile'}?`))return;const r=await fetch(`/profiles/${encodeURIComponent(id)}`,{method:'DELETE'});const d=await r.json();if(!r.ok){status.textContent=d.detail||'Could not delete profile.';return;}status.textContent='Profile deleted successfully.';await loadProfiles();}
list.addEventListener('click',e=>{const preview=e.target.closest('[data-preview]'),edit=e.target.closest('[data-edit]'),del=e.target.closest('[data-delete]');if(preview)previewProfile(preview.dataset.preview);else if(edit)editProfile(edit.dataset.edit);else if(del)deleteProfile(del.dataset.delete);});
document.getElementById('profilePreviewClose').addEventListener('click',closePreview);document.getElementById('profilePreviewCloseX').addEventListener('click',closePreview);previewModal.addEventListener('click',e=>{if(e.target===previewModal)closePreview();});
document.getElementById('profilePageSaveEdit').addEventListener('click',saveProfile);document.getElementById('profilePageCloseEdit').addEventListener('click',()=>modal.classList.add('hidden'));document.getElementById('profilePageCancelEdit').addEventListener('click',()=>modal.classList.add('hidden'));modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.add('hidden');});
loadProfiles();
