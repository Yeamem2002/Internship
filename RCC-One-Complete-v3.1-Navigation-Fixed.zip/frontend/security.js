window.currentUser=null;
window.portalView='admin';
window.authReady=(async function(){
  let r;
  try { r=await fetch('/auth/me'); } catch { location.href='/app/login.html'; return null; }
  if(!r.ok){location.href='/app/login.html';return null;}
  const user=await r.json();
  window.currentUser=user;

  const path=location.pathname.toLowerCase();
  const params=new URLSearchParams(location.search);
  const requestedView=params.get('view');
  const isProfiles=path.endsWith('/profiles.html');

  if(user.role!=='authorized'&&(path==='/app/'||path.endsWith('/index.html'))){
    location.replace('/app/profiles.html');
    return user;
  }

  window.portalView=(user.role==='authorized' && isProfiles && requestedView==='hr')?'hr':'admin';

  const badge=document.getElementById('currentUserRole');
  if(badge){
    badge.textContent=user.role==='authorized'
      ? (window.portalView==='hr'?'Authorized · HR View':'Authorized')
      : 'HR · View only';
  }

  if(user.role!=='authorized'){
    document.querySelectorAll('.authorized-only').forEach(el=>el.classList.add('hidden-by-role'));
  }

  // In HR-view mode, an authorized user sees exactly the read-only profile controls,
  // while retaining their real backend authorization.
  if(user.role==='authorized' && window.portalView==='hr'){
    document.body.classList.add('hr-view-mode');
  }

  const switchButton=document.getElementById('switchPortalButton');
  if(switchButton && user.role==='authorized'){
    if(window.portalView==='hr'){
      switchButton.textContent='Switch to Admin Portal';
      switchButton.addEventListener('click',()=>location.href='/app/');
    }else{
      switchButton.textContent='Switch to HR Portal';
      switchButton.addEventListener('click',()=>location.href='/app/profiles.html?view=hr');
    }
  }

  return user;
})();

const logout=document.getElementById('logoutButton');
if(logout)logout.addEventListener('click',async()=>{
  await fetch('/auth/logout',{method:'POST'});
  location.href='/app/login.html';
});
