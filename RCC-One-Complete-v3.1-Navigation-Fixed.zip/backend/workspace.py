"""Local prototype workspace: reviews, dashboard, activity, exports and accounts."""
import csv
import io
import json
import sqlite3
import tempfile
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from contextlib import closing

from fastapi import HTTPException, Request
from fastapi.responses import Response

STATUSES = ('submitted', 'under_review', 'approved', 'rejected')


def install_workspace(app, database, current_user, hash_password, base_dir):
    with closing(database()) as c:
        columns = {r['name'] for r in c.execute('PRAGMA table_info(applications)')}
        for name, definition in [('status', "TEXT NOT NULL DEFAULT 'submitted'"),
                                 ('review_note', "TEXT NOT NULL DEFAULT ''"),
                                 ('reviewed_by', 'TEXT'), ('reviewed_at', 'TEXT')]:
            if name not in columns:
                c.execute(f'ALTER TABLE applications ADD COLUMN {name} {definition}')
        c.execute('''CREATE TABLE IF NOT EXISTS activity (
            id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT NOT NULL,
            action TEXT NOT NULL, entity TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
        c.execute('''CREATE TABLE IF NOT EXISTS application_drafts (
            profile_id TEXT PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
            payload TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
        c.commit()

    def user(request, edit=False):
        u = current_user(request)
        if not u:
            raise HTTPException(401, 'Please log in.')
        if edit and u['role'] != 'authorized':
            raise HTTPException(403, 'Authorized personnel only. HR access is read-only.')
        return u

    def log(c, u, action, entity, detail=''):
        c.execute('INSERT INTO activity(actor,action,entity,detail) VALUES(?,?,?,?)',
                  (u['full_name'], action, entity, detail))

    @app.middleware('http')
    async def record_changes(request: Request, call_next):
        u = current_user(request) if request.method in {'POST', 'PUT', 'DELETE'} else None
        response = await call_next(request)
        path = request.url.path
        if u and 200 <= response.status_code < 300 and path.startswith(('/profiles', '/confirm', '/applications')):
            with closing(database()) as c:
                log(c, u, {'POST': 'Created / submitted', 'PUT': 'Updated', 'DELETE': 'Deleted'}[request.method], path)
                c.commit()
        response.headers['X-Content-Type-Options'] = 'nosniff'
        # Local prototype assets must not reuse a sidebar from an older build.
        response.headers['Cache-Control'] = 'no-store, max-age=0'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        return response

    @app.get('/workspace/dashboard')
    def dashboard(request: Request):
        user(request)
        with closing(database()) as c:
            counts = {t: c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]
                      for t in ('profiles', 'documents', 'applications')}
            counts['pending'] = c.execute("SELECT count(*) FROM applications WHERE status IN ('submitted','under_review')").fetchone()[0]
            recent = [dict(r) for r in c.execute('SELECT id,full_name,email,status,submitted_at FROM applications ORDER BY submitted_at DESC LIMIT 5')]
            pipeline = {s: 0 for s in STATUSES}
            pipeline.update({r['status']: r['total'] for r in c.execute('SELECT status,count(*) total FROM applications GROUP BY status')})
            attention = []
            profiles = c.execute('''SELECT p.id,p.name,p.expiry_date,
                COUNT(DISTINCT d.document_type) AS types FROM profiles p
                LEFT JOIN profile_documents pd ON pd.profile_id=p.id
                LEFT JOIN documents d ON d.id=pd.document_id GROUP BY p.id''').fetchall()
            today = datetime.now().date()
            for p in profiles:
                reasons = []
                if p['types'] < 2:
                    reasons.append('Missing ID or CV')
                expiry = None
                for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d-%m-%Y', '%Y/%m/%d', '%d.%m.%Y'):
                    try:
                        expiry = datetime.strptime(p['expiry_date'] or '', fmt).date()
                        break
                    except ValueError:
                        pass
                if expiry and expiry < today:
                    reasons.append('ID expired')
                elif expiry and expiry <= today + timedelta(days=60):
                    reasons.append('ID expires within 60 days')
                elif not expiry:
                    reasons.append('Check ID expiry date')
                if reasons:
                    attention.append({'id': p['id'], 'name': p['name'] or 'Unnamed profile', 'reasons': reasons})
            activity = [dict(r) for r in c.execute('SELECT * FROM activity ORDER BY id DESC LIMIT 5')]
        return dict(counts=counts, pipeline=pipeline, recent=recent, attention=attention, activity=activity)

    @app.patch('/workspace/applications/{application_id}')
    def review(application_id: str, data: dict, request: Request):
        u = user(request, True)
        status = data.get('status')
        note = data.get('review_note', '')
        if status not in STATUSES or not isinstance(note, str) or len(note) > 4000:
            raise HTTPException(400, 'Select a valid status and keep comments below 4,000 characters.')
        if status == 'rejected' and not note.strip():
            raise HTTPException(400, 'Please explain why the application was rejected.')
        with closing(database()) as c:
            c.execute('BEGIN IMMEDIATE')
            row = c.execute('SELECT status FROM applications WHERE id=?', (application_id,)).fetchone()
            if not row:
                raise HTTPException(404, 'Application not found.')
            if data.get('expected_status') != row['status']:
                raise HTTPException(409, 'This application changed. Close it, refresh the list, and try again.')
            c.execute('''UPDATE applications SET status=?,review_note=?,reviewed_by=?,
                reviewed_at=CURRENT_TIMESTAMP WHERE id=?''', (status, note.strip(), u['full_name'], application_id))
            log(c, u, 'Application reviewed', application_id, f"{row['status']} → {status}: {note.strip()}")
            c.commit()
        return {'message': 'Review saved.'}

    @app.get('/workspace/activity')
    def activity(request: Request):
        user(request)
        with closing(database()) as c:
            return [dict(r) for r in c.execute('SELECT * FROM activity ORDER BY id DESC LIMIT 200')]

    @app.get('/workspace/drafts/{profile_id}')
    def draft(profile_id: str, request: Request):
        user(request, True)
        with closing(database()) as c:
            row = c.execute('SELECT * FROM application_drafts WHERE profile_id=?', (profile_id,)).fetchone()
        return {'data': json.loads(row['payload']) if row else None}

    @app.put('/workspace/drafts/{profile_id}')
    def save_draft(profile_id: str, data: dict, request: Request):
        u = user(request, True)
        payload = json.dumps(data)
        if len(payload) > 100000:
            raise HTTPException(413, 'Draft is too large.')
        with closing(database()) as c:
            if not c.execute('SELECT id FROM profiles WHERE id=?', (profile_id,)).fetchone():
                raise HTTPException(404, 'Profile not found.')
            c.execute('''INSERT INTO application_drafts(profile_id,payload) VALUES(?,?)
                ON CONFLICT(profile_id) DO UPDATE SET payload=excluded.payload,updated_at=CURRENT_TIMESTAMP''', (profile_id, payload))
            log(c, u, 'Draft saved', profile_id)
            c.commit()
        return {'message': 'Draft saved locally.'}

    @app.get('/workspace/export')
    def export(request: Request, status: str = '', q: str = ''):
        u = user(request)
        with closing(database()) as c:
            rows = [dict(r) for r in c.execute('SELECT * FROM applications ORDER BY submitted_at DESC')]
            rows = [r for r in rows if (not status or r['status'] == status) and
                    (not q or q.lower() in ((r['full_name'] or '') + ' ' + (r['email'] or '')).lower())]
            columns = [r['name'] for r in c.execute('PRAGMA table_info(applications)')]
            log(c, u, 'Exported applications', 'CSV', f'{len(rows)} records')
            c.commit()
        out = io.StringIO(newline='')
        writer = csv.writer(out)
        writer.writerow(columns)
        def cell(value):
            text = '' if value is None else str(value)
            return "'" + text if text.lstrip().startswith(('=', '+', '-', '@', '\t', '\r')) else text
        writer.writerows([[cell(r.get(k)) for k in columns] for r in rows])
        return Response('\ufeff' + out.getvalue(), media_type='text/csv',
                        headers={'Content-Disposition': 'attachment; filename="applications-review.csv"'})

    @app.get('/workspace/system')
    def system(request: Request):
        user(request)
        import pytesseract
        try:
            version = str(pytesseract.get_tesseract_version()).splitlines()[0]
        except Exception:
            version = None
        return {'mode': 'Local prototype', 'ocr_version': version,
                'database': 'SQLite', 'session_hours': 8, 'max_upload_mb': 15,
                'extraction': 'Local Tesseract and PDF text; no API key needed'}

    @app.get('/workspace/backup')
    def backup(request: Request):
        u = user(request, True)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'backup.db'
            with closing(database()) as source, closing(sqlite3.connect(path)) as target:
                source.backup(target)
            content = path.read_bytes()
        with closing(database()) as c:
            log(c, u, 'Downloaded backup', 'Database')
            c.commit()
        return Response(content, media_type='application/octet-stream', headers={
            'Content-Disposition': f'attachment; filename="rcc-backup-{datetime.now():%Y%m%d-%H%M%S}.db"'})

    @app.get('/workspace/users')
    def users(request: Request):
        user(request, True)
        with closing(database()) as c:
            return [dict(r) for r in c.execute('SELECT id,full_name,email,role,created_at FROM users ORDER BY created_at DESC')]

    @app.post('/workspace/users')
    def add_user(data: dict, request: Request):
        u = user(request, True)
        import re
        name, email, password, role = [data.get(k, '') for k in ('full_name', 'email', 'password', 'role')]
        if not all(isinstance(v, str) for v in (name, email, password, role)) or not name.strip() or not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', email) or len(password) < 8 or role not in ('hr', 'authorized'):
            raise HTTPException(400, 'Enter a name, valid email, role and password of at least 8 characters.')
        with closing(database()) as c:
            try:
                c.execute('INSERT INTO users(id,full_name,email,password_hash,role) VALUES(?,?,?,?,?)',
                          (str(uuid.uuid4()), name.strip(), email.lower().strip(), hash_password(password), role))
                log(c, u, 'Account created', email.lower(), role)
                c.commit()
            except sqlite3.IntegrityError:
                raise HTTPException(409, 'This email already has an account.')
        return {'message': 'Account created.'}
