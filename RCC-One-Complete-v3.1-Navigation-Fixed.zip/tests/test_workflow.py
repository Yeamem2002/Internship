"""Run with: python -m unittest discover -s tests -v
Uses disposable files only; never touches the supplied database or workbook.
"""
import os
import tempfile
import unittest
from pathlib import Path

TMP = tempfile.TemporaryDirectory()
os.environ['DOCUMENT_DB'] = str(Path(TMP.name) / 'test.db')
from fastapi.testclient import TestClient
from backend import main
main.EXCEL_PATH = Path(TMP.name) / 'applications.xlsx'


class Workflow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with main.get_database() as c:
            for ident, role in [('admin', 'authorized'), ('hr', 'hr')]:
                c.execute('INSERT INTO users(id,full_name,email,password_hash,role) VALUES(?,?,?,?,?)',
                          (ident, ident.title(), ident+'@example.test', main.hash_password('Prototype123!'), role))
        cls.admin = TestClient(main.app)
        cls.hr = TestClient(main.app)
        for client, ident in [(cls.admin,'admin'),(cls.hr,'hr')]:
            response = client.post('/auth/login', json={'email':ident+'@example.test','password':'Prototype123!'})
            assert response.status_code == 200, response.text

    def test_01_auth_and_roles(self):
        guest = TestClient(main.app)
        for url in ['/profiles','/applications','/workspace/dashboard','/workspace/export','/workspace/users']:
            self.assertEqual(guest.get(url).status_code,401)
        self.assertEqual(self.hr.post('/profiles').status_code,403)
        self.assertEqual(self.hr.post('/applications',json={}).status_code,403)
        self.assertEqual(self.hr.get('/workspace/backup').status_code,403)
        self.assertEqual(self.hr.get('/workspace/users').status_code,403)
        self.assertEqual(self.hr.get('/workspace/dashboard').status_code,200)

    def test_02_complete_workflow(self):
        r=self.admin.post('/profiles');self.assertEqual(r.status_code,200,r.text)
        pid=r.json()['profile_id']
        data={'profile_id':pid,'document_type':'CV','filename':'sample.pdf','name':'Demo Applicant',
              'email':'demo@example.test','phone_number':'+971500000000','skills':'Python', 'education':'BSc'}
        r=self.admin.post('/confirm',json=data);self.assertEqual(r.status_code,200,r.text)
        profile=self.admin.get('/profiles/'+pid).json();self.assertEqual(profile['name'],'Demo Applicant')
        r=self.admin.put('/workspace/drafts/'+pid,json={'full_name':'Draft Person'});self.assertEqual(r.status_code,200,r.text)
        self.assertEqual(self.admin.get('/workspace/drafts/'+pid).json()['data']['full_name'],'Draft Person')
        self.assertEqual(self.admin.post('/applications',json={'profile_id':pid}).status_code,400)
        data={'profile_id':pid,'full_name':'Demo Applicant','email':'demo@example.test','skills':'=HYPERLINK("bad")'}
        r=self.admin.post('/applications',json=data);self.assertEqual(r.status_code,200,r.text)
        aid=r.json()['application_id'];self.assertTrue(r.json()['excel_saved'])
        self.assertTrue(self.admin.post('/applications',json=data).json()['duplicate'])
        url='/workspace/applications/'+aid
        self.assertEqual(self.hr.patch(url,json={'status':'approved','expected_status':'submitted'}).status_code,403)
        self.assertEqual(self.admin.patch(url,json={'status':'rejected','expected_status':'submitted'}).status_code,400)
        self.assertEqual(self.admin.patch(url,json={'status':'under_review','expected_status':'submitted','review_note':'Checking documents'}).status_code,200)
        self.assertEqual(self.admin.patch(url,json={'status':'approved','expected_status':'submitted'}).status_code,409)
        self.assertEqual(self.admin.patch(url,json={'status':'approved','expected_status':'under_review','review_note':'Reviewed in prototype'}).status_code,200)
        dash=self.admin.get('/workspace/dashboard').json();self.assertEqual(dash['pipeline']['approved'],1)
        self.assertTrue(dash['attention'])
        export=self.admin.get('/workspace/export?status=approved').text
        self.assertIn('Demo Applicant',export);self.assertIn("'=HYPERLINK",export)
        self.assertNotIn('Demo Applicant',self.admin.get('/workspace/export?status=rejected').text)
        self.assertGreater(len(self.admin.get('/workspace/activity').json()),3)
        backup=self.admin.get('/workspace/backup');self.assertEqual(backup.status_code,200)
        self.assertTrue(backup.content.startswith(b'SQLite format 3'))

    def test_03_upload_validation_and_pdf(self):
        self.assertEqual(self.admin.post('/upload',files={'file':('empty.pdf',b'','application/pdf')},data={'expected_type':'cv'}).status_code,400)
        self.assertEqual(self.admin.post('/upload',files={'file':('large.pdf',b'x'*(15*1024*1024+1),'application/pdf')},data={'expected_type':'cv'}).status_code,413)
        self.assertEqual(self.admin.post('/upload',files={'file':('data.txt',b'test','text/plain')},data={'expected_type':'cv'}).status_code,400)
        # An actual locally generated PDF exercises parsing and CV extraction.
        from pypdf import PdfWriter
        from pypdf.generic import DecodedStreamObject, DictionaryObject, NameObject
        from io import BytesIO
        w=PdfWriter();p=w.add_blank_page(width=612,height=792)
        font=DictionaryObject({NameObject('/Type'):NameObject('/Font'),NameObject('/Subtype'):NameObject('/Type1'),NameObject('/BaseFont'):NameObject('/Helvetica')})
        p[NameObject('/Resources')]=DictionaryObject({NameObject('/Font'):DictionaryObject({NameObject('/F1'):w._add_object(font)})})
        stream=DecodedStreamObject();stream.set_data(b'BT /F1 12 Tf 40 750 Td (Demo Applicant) Tj 0 -20 Td (Curriculum Vitae Resume) Tj 0 -20 Td (Email: demo@example.test) Tj 0 -20 Td (Phone: +971500000000) Tj 0 -20 Td (Education: BSc Software Engineering) Tj 0 -20 Td (Skills: Python SQL) Tj 0 -20 Td (Experience: Software Developer) Tj ET')
        p[NameObject('/Contents')]=w._add_object(stream);out=BytesIO();w.write(out)
        r=self.admin.post('/upload',files={'file':('cv.pdf',out.getvalue(),'application/pdf')},data={'expected_type':'cv'})
        self.assertEqual(r.status_code,200,r.text);self.assertEqual(r.json()['email'],'demo@example.test')

    def test_04_accounts_and_expiry(self):
        r=self.admin.post('/workspace/users',json={'full_name':'Reviewer','email':'reviewer@example.test','password':'Prototype123!','role':'hr'})
        self.assertEqual(r.status_code,200,r.text)
        self.assertNotIn('password_hash',self.admin.get('/workspace/users').text)
        expired=TestClient(main.app)
        expired.post('/auth/login',json={'email':'reviewer@example.test','password':'Prototype123!'})
        token=expired.cookies.get('elrace_session')
        with main.get_database() as c:
            c.execute("UPDATE sessions SET created_at=datetime('now','-9 hours') WHERE token=?",(token,))
        self.assertEqual(expired.get('/auth/me').status_code,401)

    def test_05_pages(self):
        for page in ['dashboard','index','profiles','applications','activity','settings','form','login','role-login','signup']:
            r=self.admin.get('/app/'+page+'.html');self.assertEqual(r.status_code,200)
            self.assertIn('workspace.css',r.text)

if __name__=='__main__':
    unittest.main()
