(async()=>{
 const $=id=>document.getElementById(id), esc=window.escapeText;
 const label=s=>({submitted:'Submitted',under_review:'Under review',approved:'Approved',rejected:'Rejected'}[s]||s);
 const badge=s=>`<span class="pill ${esc(s)}">${esc(label(s))}</span>`;
 const date=s=>{if(!s)return '—';const d=new Date(s.replace(' ','T')+(s.includes('Z')||/[+]\d\d:\d\d$/.test(s)?'':'Z'));return isNaN(d)?esc(s):d.toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'});};
 const person=r=>`<div class="person"><span class="avatar">${esc((r.full_name||r.name||'?').split(' ').filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase())}</span><div><strong>${esc(r.full_name||r.name||'Unnamed')}</strong><small>${esc(r.email||'No email recorded')}</small></div></div>`;
 const empty=(title,text)=>`<div class="empty">${icon('folder')}<strong>${esc(title)}</strong>${esc(text||'')}</div>`;
 async function api(url,options){const r=await fetch(url,options);let data;try{data=await r.json();}catch{throw Error('The server returned an unexpected response.');}if(r.status===401){location.href='login.html';throw Error('Please sign in again.');}if(!r.ok)throw Error(typeof data.detail==='string'?data.detail:'Unable to complete this action.');return data;}
 function report(e){$('pageError').textContent=e.message||'Could not connect to the local server.';}
 const u=await window.authReady;if(!u)return;
 const editable=u.role==='authorized';
 const page=document.body.dataset.page;
 let records=[],selected=null,events=[];
 function applicationRows(rows,full=false){return rows.length?`<table class="data-table"><thead><tr><th>Employee</th><th>Status</th><th>Submitted</th>${full?'<th>Action</th>':''}</tr></thead><tbody>${rows.map(r=>`<tr><td>${person(r)}</td><td>${badge(r.status)}</td><td>${date(r.submitted_at)}</td>${full?`<td><button class="btn" data-review="${esc(r.id)}">${editable?'Review':'View'}</button></td>`:''}</tr>`).join('')}</tbody></table>`:empty('No applications yet','Submit a confirmed profile from the document center.');}
 function activityRows(rows){return rows.length?rows.map(r=>`<div class="activity-row"><span class="activity-dot"></span><div><strong>${esc(r.action)}</strong><p>${esc(r.actor)} · ${date(r.created_at)}</p></div></div>`).join(''):empty('A fresh activity history','Actions will appear here as you use this upgraded workspace.');}
 try{
 if(page==='dashboard'){
  const d=await api('/workspace/dashboard');
  const stats=[['profiles','Employee profiles','Saved in this workspace','people'],['documents','Documents','Confirmed document records','folder'],['applications','Applications','Submitted applications','file'],['pending','Awaiting decision','Submitted or under review','clock']];
  $('stats').innerHTML=stats.map(([key,title,sub,ico])=>`<div class="stat"><div class="stat-top">${title}${icon(ico)}</div><strong>${d.counts[key]}</strong><small>${sub}</small></div>`).join('');
  $('recent').innerHTML=applicationRows(d.recent);
  $('pipeline').innerHTML=Object.entries(d.pipeline).map(([s,n])=>`<div class="pipeline-row"><div class="pipeline-label"><span>${label(s)}</span><strong>${n}</strong></div><div class="track"><span style="width:${d.counts.applications?n/d.counts.applications*100:0}%;background:${s==='approved'?'#6baa90':s==='rejected'?'#ce8590':s==='under_review'?'#d2b36d':'#6885ab'}"></span></div></div>`).join('');
  $('attentionCount').textContent=d.attention.length+' profiles';
  $('attention').innerHTML=d.attention.length?d.attention.map(r=>`<div class="notice-row"><span class="notice-icon">!</span><div><strong>${esc(r.name)}</strong><p>${esc(r.reasons.join(' · '))}</p></div><a href="${editable?'index.html?profile_id='+encodeURIComponent(r.id):'profiles.html'}">Open →</a></div>`).join(''):empty('All caught up','Both document types and a valid expiry date are recorded for each profile.');
  $('recentActivity').innerHTML=activityRows(d.activity);
 }
 if(page==='applications'){
  function render(){const q=$('applicationSearch').value.toLowerCase().trim(),s=$('statusFilter').value;const rows=records.filter(r=>(!s||r.status===s)&&(!q||((r.full_name||'')+' '+(r.email||'')).toLowerCase().includes(q)));$('applicationTable').innerHTML=applicationRows(rows,true);$('applicationCount').textContent=`${rows.length} of ${records.length} applications · CSV export follows these filters`;}
  async function load(){records=await api('/applications');render();}
  $('applicationSearch').oninput=render;$('statusFilter').onchange=render;
  $('refreshApplications').onclick=()=>load().catch(report);
  $('exportButton').onclick=()=>{location.href='/workspace/export?'+new URLSearchParams({status:$('statusFilter').value,q:$('applicationSearch').value.trim()});};
  $('applicationTable').onclick=e=>{const b=e.target.closest('[data-review]');if(!b)return;selected=records.find(r=>r.id===b.dataset.review);if(!selected)return;const r=selected;$('applicationName').textContent=r.full_name||'Unnamed applicant';$('applicationMeta').innerHTML=badge(r.status)+` <span class="subtle">Submitted ${date(r.submitted_at)}</span>`;
   const fields=[['id','Application ID'],['email','Email'],['phone_number','Phone'],['nationality','Nationality'],['date_of_birth','Date of birth'],['document_number','Emirates ID'],['issue_date','Issue date'],['expiry_date','Expiry date'],['education','Education'],['skills','Skills'],['experience','Experience'],['projects','Projects'],['review_note','Review comments'],['reviewed_by','Reviewed by']];
   $('applicationDetails').innerHTML=fields.map(([key,title])=>`<div class="${['education','skills','experience','projects','review_note'].includes(key)?'wide':''}"><dt>${title}</dt><dd>${esc(r[key]||'—')}</dd></div>`).join('');
   $('reviewStatus').value=r.status;$('reviewNote').value=r.review_note||'';$('reviewMessage').textContent='';$('applicationDialog').showModal();
  };
  $('closeApplication').onclick=()=>$('applicationDialog').close();
  $('saveReview').onclick=async()=>{const b=$('saveReview');b.disabled=true;try{await api('/workspace/applications/'+encodeURIComponent(selected.id),{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:$('reviewStatus').value,review_note:$('reviewNote').value,expected_status:selected.status})});$('applicationDialog').close();toast('Review saved.');await load();}catch(e){$('reviewMessage').textContent=e.message;}finally{b.disabled=false;}};
  await load();
 }
 if(page==='activity'){
  function render(){const q=$('activitySearch').value.toLowerCase();const rows=events.filter(r=>[r.action,r.actor,r.entity,r.detail].some(v=>(v||'').toLowerCase().includes(q)));$('activityTable').innerHTML=rows.length?`<table class="data-table"><thead><tr><th>Action</th><th>Performed by</th><th>Record / details</th><th>Date</th></tr></thead><tbody>${rows.map(r=>`<tr><td><strong>${esc(r.action)}</strong></td><td>${esc(r.actor)}</td><td>${esc(r.entity)}<small>${esc(r.detail)}</small></td><td>${date(r.created_at)}</td></tr>`).join('')}</tbody></table>`:empty('No activity to show','Recorded actions will appear here.');}
  async function load(){events=await api('/workspace/activity');render();}
  $('activitySearch').oninput=render;$('refreshActivity').onclick=()=>load().catch(report);await load();
 }
 if(page==='settings'){
  const d=await api('/workspace/system');$('systemInfo').innerHTML=[['Environment',d.mode],['Database',d.database],['OCR engine',d.ocr_version?'Tesseract '+d.ocr_version:'Not installed / not found'],['Session duration',d.session_hours+' hours'],['Maximum upload',d.max_upload_mb+' MB']].map(([k,v])=>`<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('');
  if(editable){
   async function loadUsers(){const rows=await api('/workspace/users');$('usersTable').innerHTML=`<table class="data-table"><thead><tr><th>Name</th><th>Email</th><th>Access</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.full_name)}</td><td>${esc(r.email)}</td><td><span class="pill">${r.role==='authorized'?'Authorized':'HR · Read only'}</span></td></tr>`).join('')}</tbody></table>`;}
   await loadUsers();$('newUser').onclick=()=>{$('userForm').reset();$('userMessage').textContent='';$('userDialog').showModal();};$('closeUser').onclick=()=>$('userDialog').close();
   $('userForm').onsubmit=async e=>{e.preventDefault();const b=e.submitter;b.disabled=true;try{await api('/workspace/users',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({full_name:$('userName').value,email:$('userEmail').value,password:$('userPassword').value,role:$('userRole').value})});$('userDialog').close();$('userPassword').value='';toast('Account created.');await loadUsers();}catch(e){$('userMessage').textContent=e.message;}finally{b.disabled=false;}};
   $('syncExcel').onclick=async()=>{$('syncExcel').disabled=true;try{const r=await api('/applications/sync-excel',{method:'POST'});$('syncMessage').textContent=`Updated ${r.applications_exported} applications and ${r.profiles_exported} profiles.`;}catch(e){$('syncMessage').textContent=e.message;}finally{$('syncExcel').disabled=false;}};
  }
 }
 }catch(e){report(e);}
})();
