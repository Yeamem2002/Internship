# RCC One · Final command center package
A project-first workspace for EL Race internship review, built on the existing employee-document prototype. Not a production ERP or a validated Odoo replacement. See RESEARCH_AND_BLUEPRINT.md for evidence, scope and roadmap.

## Start the fictional demonstration (recommended for supervisor review)
Requires Python 3.10+ and a modern browser. On Windows, double-click `START_RCC.bat`. Alternatively:

```sh
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python demo.py
```

Open http://127.0.0.1:8000 in your browser. Select Admin access. Email is `demo@rcc.local`; use the random password printed in the terminal. The demo stores changes in `rcc_demo.db` and uses a separate workbook. Password changes each launch. Stop with Ctrl+C. The installer needs an internet connection; normal prototype use runs locally. OCR also requires Tesseract installed locally, but operations features do not.

All demo names, amounts and projects are fictional. Do not run two launchers on port 8000 simultaneously.

## Use the preserved employee workspace
`python run.py` or `start_windows.bat` uses `document_autofill.db` and `applications.xlsx`, preserving the records supplied with the original project. Existing credentials remain unchanged; no password is printed or reset. If needed, run `python create_authorized_user.py` to create a new authorized local account. The construction tables start empty in this mode. A pre-v2 SQLite backup is made by the retained migration logic if absent; make a current manual backup before future migration work.

The package contains the original prototype's employee records and password hashes. Keep it within the authorized project team. The demo does not load those records. No API key is included or needed. No external company account is connected.

## Screens and behavior
Command center → project portfolio, work register, decision queue, site diary.
People overview → document collection, extraction/review, employee profiles, application review, exports, activity and accounts.
Project details show baseline budget, approved procurement commitments and approved variation value separately. Search and filters affect the current list; the four top metrics are always organization-wide. Register export includes all register records, not the current view filter.

Authorized accounts edit; HR accounts view only. These are prototype roles. All work entries use one simplified review workflow; no purchasing documents are issued. Dates follow the local server's calendar and history timestamps are UTC.

## Verify
```sh
python -m pip install -r requirements-dev.txt
python -m unittest discover -s tests -v
```
Tests use disposable SQLite and Excel files. TEST_REPORT.md records this build's verification. Screenshots are in previews/. The original v2 ZIP remains a separate earlier deliverable.

## Final package updates
The ZIP contains the project files directly at its root. Start from the folder containing START_RCC.bat and demo.py. Summary cards open the relevant view. The work register supports status and overdue filters, clear filters and refresh. CSV export deliberately includes all register records.

## Navigation fix v3.1
The shared sidebar now loads from shell-rcc-v31.js on every page. Projects / Command Center is the first navigation entry. All script/style URLs are versioned, and responses disable caching to prevent older navigation from appearing with newer screens.
