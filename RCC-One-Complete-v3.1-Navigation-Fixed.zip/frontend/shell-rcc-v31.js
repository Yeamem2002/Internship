(() => {
  const paths={grid:'M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z',folder:'M3 7V5h6l2 2h10v13H3z',people:'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M20 21v-2a4 4 0 0 0-3-3.9 M16 3a4 4 0 0 1 0 8',file:'M14 2H5v20h14V7z M14 2v6h5 M8 12h8 M8 16h6',clock:'M12 8v5l3 2 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',settings:'M12 3v3 M12 18v3 M3 12h3 M18 12h3 M5.6 5.6l2.2 2.2 M16.2 16.2l2.2 2.2 M5.6 18.4l2.2-2.2 M16.2 7.8l2.2-2.2 M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0',arrow:'M5 12h14 M13 6l6 6-6 6',download:'M12 3v12 M7 10l5 5 5-5 M4 17v4h16v-4',menu:'M4 6h16 M4 12h16 M4 18h16'};
  window.icon = name => `<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name]||paths.file}"/></svg>`;
  window.escapeText = value => String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  window.toast = text => {document.querySelector('.toast')?.remove();const el=document.createElement('div');el.className='toast';el.role='status';el.textContent=text;document.body.append(el);setTimeout(()=>el.remove(),4500);};
  if(document.body.classList.contains('auth-page')){
    const aside=document.createElement('aside');aside.className='auth-aside';aside.innerHTML='<div class="auth-mark">EL RACE · RCC ONE · OPERATIONS</div><h2>Every project.<br>Moving forward.</h2><p>A connected workspace for project delivery, construction decisions and people operations.</p><div class="auth-steps"><span>01 &nbsp; See project priorities</span><span>02 &nbsp; Review work and decisions</span><span>03 &nbsp; Connect your people operations</span></div><small>RCC One · Local prototype</small>';document.body.prepend(aside);return;
  }
  document.body.classList.add('workspace-layout');
  const sidebar=document.createElement('aside');sidebar.className='sidebar';sidebar.id='sidebar';
  const nav=[['operations.html','grid','Projects / Command Center'],['dashboard.html','people','People overview'],['index.html','folder','Document center'],['profiles.html','people','Employee profiles'],['applications.html','file','Applications'],['activity.html','clock','Activity history'],['settings.html','settings','System & accounts']];
  const current=location.pathname.split('/').pop()||'index.html';
  sidebar.innerHTML=`<a class="sidebar-brand" href="operations.html" aria-label="RCC overview"><img src="el-race-logo.png" alt="RCC EL Race"></a><p class="sidebar-caption">RCC ONE · OPERATIONS</p><nav aria-label="Main navigation">${nav.map(([href,ico,title])=>`<a href="${href}" class="${href===current?'active':''} ${href==='index.html'?'authorized-only':''}" ${href===current?'aria-current="page"':''}>${icon(ico)}${title}</a>`).join('')}</nav><div class="sidebar-foot"><div class="local-tag">Local prototype</div>Prepared for supervisor review<br><span>RCC One · v3.1</span></div>`;
  document.body.prepend(sidebar);
  let shell=document.querySelector('.page-shell');
  if(!shell){shell=document.createElement('div');shell.className='page-shell';const main=document.querySelector('main');main.before(shell);shell.append(main);}
  let topbar=document.querySelector('.topbar');
  if(!topbar){topbar=document.createElement('header');topbar.className='topbar';topbar.innerHTML='<div class="brand"><div><div class="brand-title">RCC One</div><div class="brand-subtitle">EL Race Construction & General Contracting</div></div></div><div class="user-menu"><span id="currentUserRole" class="role-badge">Connecting…</span><button id="logoutButton" class="logout-button">Sign out</button></div>';shell.prepend(topbar);}
  const menu=document.createElement('button');menu.className='mobile-menu';menu.type='button';menu.setAttribute('aria-label','Toggle navigation');menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-controls','sidebar');menu.innerHTML=icon('menu');topbar.prepend(menu);menu.onclick=()=>{sidebar.classList.toggle('open');menu.setAttribute('aria-expanded',sidebar.classList.contains('open'));};
  document.addEventListener('click',e=>{if(!sidebar.contains(e.target)&&!menu.contains(e.target)){sidebar.classList.remove('open');menu.setAttribute('aria-expanded','false');}});
  const foot=document.createElement('footer');foot.className='footer-note';foot.textContent='RCC One • Local prototype • Changes are saved on this computer';shell.append(foot);
  // Give the retained upload/edit dialogs keyboard semantics and focus containment.
  let lastFocus=null;
  document.querySelectorAll('.modal-overlay').forEach(overlay=>{
    overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');const title=overlay.querySelector('h2');if(title){if(!title.id)title.id=overlay.id+'Title';overlay.setAttribute('aria-labelledby',title.id);}
    new MutationObserver(()=>{if(!overlay.classList.contains('hidden')){lastFocus=document.activeElement;overlay.querySelector('input,button,textarea')?.focus();}else if(lastFocus?.isConnected)lastFocus.focus();}).observe(overlay,{attributes:true,attributeFilter:['class']});
    overlay.addEventListener('keydown',e=>{const controls=[...overlay.querySelectorAll('button,input,textarea,select,a[href]')].filter(x=>!x.disabled&&x.offsetParent!==null);if(e.key==='Escape'){overlay.querySelector('.close-button')?.click();}if(e.key==='Tab'&&controls.length){const first=controls[0],last=controls.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}});
  });
})();
