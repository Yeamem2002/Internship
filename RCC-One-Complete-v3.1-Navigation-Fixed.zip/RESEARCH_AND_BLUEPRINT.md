# RCC One — research and implementation blueprint
Research date: 6 October 2026. Local internship prototype; no workplace deployment.

## What the public evidence tells us

| Source | Observation | Design implication (our inference) |
|---|---|---|
| https://elrace.com/ and https://elrace.com/projects | EL Race presents education, healthcare, residential, government and private work. Its service descriptions include site analysis, project management, permits, general contracting and renovation. | Organize the experience around projects and construction disciplines. |
| https://elrace.com/qhse | The public QHSE page lists risk, environmental, policy and responsibility documents. | Provide a corrective-action register with responsible owner, due date and recorded decisions. This is not a certification or a substitute for the official registers. |
| https://elrace.com/careers | Public vacancies include project, contract and engineering management roles. | Engineering requests and commercial changes belong beside delivery tracking. |
| https://erp.elrace.com/who-we-are | An EL Race public site identifies Odoo in its footer. | Investigate integration before deciding to replace an incumbent. A public footer does not reveal the company's internal modules, version, configuration or problems. |

We did not access internal systems or contact the company. Public project counters and mismatched news links were excluded from design assumptions. The demonstration projects, managers, amounts, progress and deadlines are fictional, not claims about EL Race's real operations.

## A fair comparison with Odoo
Official sources: https://www.odoo.com/documentation/19.0/applications/services/project.html ; https://www.odoo.com/documentation/19.0/applications/inventory_and_mrp/purchase.html ; https://www.odoo.com/documentation/19.0/vi/applications/services/project/project_management/project_profitability.html

Odoo already provides project tasks, milestones and profitability reporting, as well as purchase agreements, quotations and orders. Its project profitability reporting can connect project-related costs and revenues. RCC One is not yet an equivalent ERP. Its proposed advantage is a compact, construction-specific daily workflow connected to the existing employee-document prototype.

| Area | Implemented in this prototype | What must be assessed before replacing Odoo |
|---|---|---|
| Project visibility | Portfolio, sector, location, manager, baseline budget, due date, manually reported progress | Scheduling dependencies, baseline revisions, earned value and actual cost integration |
| Purchasing | Request register, estimated values, review and closure history | Vendor master, tender comparison, PO issuance, receipts, invoicing and inventory |
| Engineering | RFI, submittal and permit records, ownership and decisions | Drawing storage, revisions, transmittals and external consultant approvals |
| QHSE | Corrective actions, priorities, deadlines, required review/closure notes | Severity-specific routing, inspection evidence, incident confidentiality and formal compliance procedures |
| Commercial | Variation value register, review history, separate approved-value totals | BOQ measurement, valuations, retention, payment certification and finance reconciliation |
| Site reporting | One daily report per project/date, manpower, hours, completed work and blockers | Worker assignments, equipment allocation, timesheets, offline capture and amendments |
| People | Retained document extraction, manual confirmation, employee profiles and application review | HR access review, original-document storage, visa workflows, payroll and leave |

## What works today
- Authenticated local web application using the existing FastAPI/SQLite foundation.
- Responsive operations command center, project portfolio and project detail dialogs.
- Create and update projects; update progress with protection against stale edits.
- Create six kinds of work register entry with project, owner, priority, deadline and narrative.
- Controlled workflow: open → in review → approved → closed; in review → rejected → open permits resubmission. Every transition requires a note; the update, history and activity entry commit together.
- Decisions queue, overdue indicators, project/discipline/search filters and CSV register export.
- Daily site reporting with duplicate-date and future-date checks.
- Existing document, profile and application workspace accessible through the same navigation.
- Isolated optional demo using only fictional project data; unique generated login password each launch.

## Deliberate prototype boundaries
Two existing access levels remain: Authorized can change records; HR is read-only, including operations. This is demonstration behavior, not an approved company authorization matrix. No project-level permissions or separation of requester and approver is implemented. An authorized person can review their own request. Owners are text fields, not linked user assignments.

Procurement totals count approved/closed request estimates once. They are not posted purchases, expenditure, cash flow, earned value or profit. Approved variations are displayed separately and never silently change the baseline. Progress is manually entered, not schedule-derived. A closure note is narrative evidence only; attachments and verification are not implemented. Current register entries are immutable after creation except for workflow state; record correction/cancellation and daily-report amendments are future work. No emails, purchase orders or external notifications are sent.

The existing HR module's limits remain: no archive of original uploaded documents, limited scan support, OCR requires manual review, local authentication without production identity infrastructure. The public HR sign-up route is retained and should be redesigned before workplace use. SQLite backups contain personal data; no encryption-at-rest, production audit retention or recovery service is claimed. Every authenticated user can currently view all projects.

## Supervisor validation before implementation
1. Confirm current Odoo modules, licenses, customizations, pain points and data owners through an authorized internal discovery session.
2. Map one real process in each team: requisition, engineering query, QHSE action, variation and employee onboarding. Agree required fields, reviewer authority, rejection, correction and closure rules.
3. Run matched scenarios with representative users in both systems. Measure median time, clicks, repeated data entry, errors and missing hand-offs. A proposed acceptance target is 25% less handling time without losing controls; this target has not been tested or achieved.
4. Decide whether RCC One should be an Odoo companion or a replacement. Prefer staged integration if finance, purchasing and inventory already work reliably in Odoo.
5. Before a controlled pilot: implement company roles/project access, identity/SSO, separation of duties, secure attachments, full audit retention, tested restore, data migration reconciliation and user acceptance testing. Finance rules require finance-team validation.
6. Consider Arabic/RTL, mobile/offline use, equipment, subcontractors, timesheets, document control, BOQ and dashboards only after prioritization. These are roadmap items, not enabled modules.

## Suggested supervisor walkthrough
Start the isolated demo. Open Al Waha Learning Campus, inspect its baseline and commitments, then open project work. Review the steel request and record an approval note. Confirm it leaves the decision queue and increases the committed procurement indicator. Open the QHSE action, move it through review and approval, then close it with a completion note. Add a site report for another project. Open the People overview to inspect the preserved HR flow. All changes persist locally in the demo database.
