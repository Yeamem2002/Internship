(async()=>{
 const user=await window.authReady;if(!user)return;
 if(user.role!=='authorized'){location.href='applications.html';return;}
 const profileId=new URLSearchParams(location.search).get('profile_id');
 const form=document.getElementById('applicationForm'),status=document.getElementById('status'),submit=form.querySelector('[type=submit]'),save=document.getElementById('saveDraft');
 const fields={full_name:'fullName',date_of_birth:'dob',nationality:'formNationality',email:'formEmail',phone_number:'formPhone',document_number:'emiratesId',issue_date:'formIssueDate',expiry_date:'formExpiryDate',education:'formEducation',skills:'formSkills',experience:'formExperience',projects:'formProjects'};
 function values(){const data={profile_id:profileId};Object.entries(fields).forEach(([key,id])=>data[key]=document.getElementById(id).value.trim()||null);return data;}
 function fill(data){Object.entries(fields).forEach(([key,id])=>document.getElementById(id).value=data[key]||'');}
 async function api(url,options){const r=await fetch(url,options);const d=await r.json();if(!r.ok)throw Error(typeof d.detail==='string'?d.detail:'Could not save application.');return d;}
 function options(data,method='POST'){return {method,headers:{'Content-Type':'application/json'},body:JSON.stringify(data)};}
 submit.disabled=save.disabled=true;
 if(!profileId){status.textContent='Select a profile from the document center first.';return;}
 let dirty=false,completed=false;form.addEventListener('input',()=>dirty=true);
 window.addEventListener('beforeunload',e=>{if(dirty&&!completed){e.preventDefault();e.returnValue='';}});
 try{
  const p=await api('/profiles/'+encodeURIComponent(profileId));fill({...p,full_name:p.name});
  const draft=await api('/workspace/drafts/'+encodeURIComponent(profileId));
  if(draft.data){fill(draft.data);status.textContent='Your saved draft has been restored.';}
  else status.textContent='Autofilled from the confirmed profile. Review the details before submitting.';
  submit.disabled=save.disabled=false;
 }catch(e){status.textContent=e.message;return;}
 save.onclick=async()=>{save.disabled=true;try{await api('/workspace/drafts/'+encodeURIComponent(profileId),options(values(),'PUT'));dirty=false;status.textContent='Draft saved locally. You can return to this profile to continue.';toast('Draft saved.');}catch(e){status.textContent=e.message;}finally{save.disabled=false;}};
 form.onsubmit=async e=>{e.preventDefault();submit.disabled=true;save.disabled=true;status.textContent='Submitting application…';try{const r=await api('/applications',options(values()));completed=true;dirty=false;status.textContent=r.duplicate?'This profile already has an application. Open Applications to review it.':r.excel_saved?'Application submitted and Excel synchronized.':'Application saved. Excel could not be synchronized; close Excel and use System & accounts to retry.';const a=document.createElement('a');a.href='applications.html';a.textContent=' View applications →';status.append(a);submit.textContent=r.duplicate?'Already submitted':'Submitted ✓';}catch(e){status.textContent=e.message;submit.disabled=save.disabled=false;}};
})();
