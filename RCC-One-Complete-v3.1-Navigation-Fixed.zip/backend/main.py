import os
import shutil
import re

import sqlite3

import uuid
import hashlib
import hmac
import secrets

from io import BytesIO

from pathlib import Path

from collections import Counter

from difflib import SequenceMatcher

from datetime import datetime

import pytesseract

from PIL import Image, ImageEnhance, ImageFilter, ImageOps

from fastapi import (

    FastAPI,

    UploadFile,

    File,

    HTTPException,

    Form,
    Request,
    Response

)

from fastapi.middleware.cors import CORSMiddleware

from fastapi.staticfiles import StaticFiles

from pypdf import PdfReader
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment

# =========================================================

# TESSERACT

# =========================================================

pytesseract.pytesseract.tesseract_cmd = os.environ.get("TESSERACT_CMD") or shutil.which("tesseract") or r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# =========================================================

# FASTAPI

# =========================================================

app = FastAPI(

    title="Document Autofill API"

)

app.add_middleware(

    CORSMiddleware,

    allow_origins=[],

    allow_credentials=False,

    allow_methods=["*"],

    allow_headers=["*"],

)

@app.get("/")

def home():

    return __import__("fastapi").responses.RedirectResponse("/app/operations.html")

# =========================================================

# DATABASE

# =========================================================

BASE_DIR = Path(__file__).resolve().parent.parent
DATABASE_PATH = Path(os.environ.get("DOCUMENT_DB", str(BASE_DIR / "document_autofill.db")))
# Keep one untouched pre-upgrade snapshot for rollback.
if DATABASE_PATH.exists() and not DATABASE_PATH.with_suffix(".pre-v2.db").exists():
    with sqlite3.connect(DATABASE_PATH) as source, sqlite3.connect(DATABASE_PATH.with_suffix(".pre-v2.db")) as target:
        source.backup(target)

def get_database():

    connection = sqlite3.connect(

        DATABASE_PATH

    )

    connection.row_factory = sqlite3.Row

    connection.execute(

        "PRAGMA foreign_keys = ON"

    )

    return connection

def create_database():

    connection = get_database()

    # -----------------------------------------------------

    # DOCUMENTS

    # -----------------------------------------------------

    connection.execute(

        """

        CREATE TABLE IF NOT EXISTS documents (

            id TEXT PRIMARY KEY,

            document_type TEXT NOT NULL,

            filename TEXT,

            name TEXT,

            document_number TEXT,

            date_of_birth TEXT,

            nationality TEXT,

            issue_date TEXT,

            expiry_date TEXT,

            email TEXT,

            phone_number TEXT,

            skills TEXT,

            education TEXT,

            experience TEXT,

            projects TEXT,

            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

        )

        """

    )

    # -----------------------------------------------------

    # PROFILES

    # -----------------------------------------------------

    connection.execute(

        """

        CREATE TABLE IF NOT EXISTS profiles (

            id TEXT PRIMARY KEY,

            name TEXT,

            email TEXT,

            phone_number TEXT,

            document_number TEXT,

            date_of_birth TEXT,

            nationality TEXT,

            issue_date TEXT,

            expiry_date TEXT,

            skills TEXT,

            education TEXT,

            experience TEXT,

            projects TEXT,

            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

        )

        """

    )

    # -----------------------------------------------------

    # PROFILE DOCUMENT CONNECTION

    # -----------------------------------------------------

    connection.execute(

        """

        CREATE TABLE IF NOT EXISTS profile_documents (

            id TEXT PRIMARY KEY,

            profile_id TEXT NOT NULL,

            document_id TEXT NOT NULL,

            FOREIGN KEY (profile_id)

                REFERENCES profiles(id)

                ON DELETE CASCADE,

            FOREIGN KEY (document_id)

                REFERENCES documents(id)

                ON DELETE CASCADE,

            UNIQUE(profile_id, document_id)

        )

        """

    )

    # -----------------------------------------------------
    # APPLICATIONS
    # -----------------------------------------------------

    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS applications (
            id TEXT PRIMARY KEY,
            profile_id TEXT NOT NULL,

            full_name TEXT,
            date_of_birth TEXT,
            nationality TEXT,
            email TEXT,
            phone_number TEXT,

            document_number TEXT,
            issue_date TEXT,
            expiry_date TEXT,

            education TEXT,
            skills TEXT,
            experience TEXT,
            projects TEXT,

            submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (profile_id)
                REFERENCES profiles(id)
                ON DELETE CASCADE
        )
        """
    )

    connection.commit()

    connection.close()

create_database()

# Authentication tables
def create_auth_tables():
    connection = get_database()
    connection.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            full_name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('hr', 'authorized')),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    connection.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            token TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)
    connection.commit()
    connection.close()

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)
    return f"{salt.hex()}:{digest.hex()}"

def verify_password(password: str, stored: str) -> bool:
    try:
        salt_hex, expected_hex = stored.split(":", 1)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), 200_000)
        return hmac.compare_digest(digest.hex(), expected_hex)
    except Exception:
        return False

def user_from_request(request: Request):
    token = request.cookies.get("elrace_session")
    if not token:
        return None
    connection = get_database()
    row = connection.execute("""
        SELECT users.id, users.full_name, users.email, users.role
        FROM sessions JOIN users ON users.id = sessions.user_id
        WHERE sessions.token = ? AND sessions.created_at > datetime('now', '-8 hours')
    """, (token,)).fetchone()
    connection.close()
    return dict(row) if row else None

create_auth_tables()

@app.middleware("http")
async def security_layer(request: Request, call_next):
    path = request.url.path
    protected = path.startswith(("/upload", "/confirm", "/documents", "/profiles", "/applications", "/workspace"))
    if protected:
        user = user_from_request(request)
        if not user:
            return __import__('fastapi').responses.JSONResponse(status_code=401, content={"detail": "Please log in."})

        # HR is read-only for employee/document information.
        mutates_employee_data = (
            path.startswith(("/upload", "/confirm")) or
            (path == "/profiles" and request.method == "POST") or
            (path.startswith("/profiles/") and request.method in {"PUT", "DELETE"}) or
            (path.startswith("/applications") and request.method not in {"GET", "HEAD"})
        )
        if mutates_employee_data and user["role"] != "authorized":
            return __import__('fastapi').responses.JSONResponse(status_code=403, content={"detail": "Authorized personnel only."})

    return await call_next(request)

@app.post("/auth/signup")
async def signup(request: Request):
    data = await request.json()
    full_name = (data.get("full_name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    if not full_name or not email or len(password) < 8:
        raise HTTPException(status_code=400, detail="Enter your name, email, and a password of at least 8 characters.")
    connection = get_database()
    try:
        user_id = str(uuid.uuid4())
        connection.execute("INSERT INTO users (id, full_name, email, password_hash, role) VALUES (?, ?, ?, ?, 'hr')",
                           (user_id, full_name, email, hash_password(password)))
        connection.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="An account with this email already exists.")
    finally:
        connection.close()
    return {"message": "HR account created. You can now log in."}

@app.post("/auth/login")
async def login(request: Request, response: Response):
    data = await request.json()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    portal_role = (data.get("portal_role") or "").strip().lower()
    connection = get_database()
    row = connection.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    if not row or not verify_password(password, row["password_hash"]):
        connection.close()
        raise HTTPException(status_code=401, detail="Incorrect email or password.")
    if portal_role in {"hr", "authorized"} and row["role"] != portal_role:
        connection.close()
        label = "Admin" if portal_role == "authorized" else "HR"
        raise HTTPException(status_code=403, detail=f"This account does not have {label} access.")
    token = secrets.token_urlsafe(32)
    connection.execute("INSERT INTO sessions (token, user_id) VALUES (?, ?)", (token, row["id"]))
    connection.commit(); connection.close()
    response.set_cookie("elrace_session", token, httponly=True, samesite="strict", max_age=28800, path="/")
    return {"id": row["id"], "full_name": row["full_name"], "email": row["email"], "role": row["role"]}

@app.post("/auth/logout")
def logout(request: Request, response: Response):
    token = request.cookies.get("elrace_session")
    if token:
        connection = get_database(); connection.execute("DELETE FROM sessions WHERE token = ?", (token,)); connection.commit(); connection.close()
    response.delete_cookie("elrace_session", path="/")
    return {"message": "Logged out."}

@app.get("/auth/me")
def me(request: Request):
    user = user_from_request(request)
    if not user:
        raise HTTPException(status_code=401, detail="Not logged in.")
    return user

# =========================================================

# PROFILE MERGING

# =========================================================

PROFILE_FIELDS = [

    "name",

    "email",

    "phone_number",

    "document_number",

    "date_of_birth",

    "nationality",

    "issue_date",

    "expiry_date",

    "skills",

    "education",

    "experience",

    "projects"

]

def merge_document_into_profile(

    connection,

    profile_id,

    data

):

    profile = connection.execute(

        """

        SELECT *

        FROM profiles

        WHERE id = ?

        """,

        (

            profile_id,

        )

    ).fetchone()

    if not profile:

        raise HTTPException(

            status_code=404,

            detail="Profile not found."

        )

    profile_data = dict(

        profile

    )

    updates = {}

    for field in PROFILE_FIELDS:

        new_value = data.get(

            field

        )

        old_value = profile_data.get(

            field

        )

        # Ignore empty values.

        if new_value in (

            None,

            ""

        ):

            continue

        # Fill empty profile fields.

        if not old_value:

            updates[field] = (

                new_value

            )

        # Name is shared by CV and Emirates ID.

        # For this basic framework the latest

        # user-confirmed name is accepted.

        elif field == "name":

            updates[field] = (

                new_value

            )

    if not updates:

        return

    set_parts = []

    values = []

    for field, value in updates.items():

        set_parts.append(

            f"{field} = ?"

        )

        values.append(

            value

        )

    set_parts.append(

        "updated_at = CURRENT_TIMESTAMP"

    )

    values.append(

        profile_id

    )

    connection.execute(

        f"""

        UPDATE profiles

        SET {", ".join(set_parts)}

        WHERE id = ?

        """,

        values

    )

# =========================================================

# IDENTITY VALIDATION

# =========================================================

def normalize_person_name(name):

    if not name:

        return ""

    name = name.lower()

    name = re.sub(r"[^a-z0-9\s]", " ", name)

    return " ".join(name.split())

def calculate_name_similarity(name1, name2):

    name1 = normalize_person_name(name1)

    name2 = normalize_person_name(name2)

    if not name1 or not name2:

        return None

    return SequenceMatcher(None, name1, name2).ratio()

def validate_document_identity(connection, profile_id, new_data):

    profile = connection.execute(

        "SELECT * FROM profiles WHERE id = ?",

        (profile_id,)

    ).fetchone()

    if not profile:

        raise HTTPException(status_code=404, detail="Profile not found.")

    profile_data = dict(profile)

    existing_name = profile_data.get("name")

    new_name = new_data.get("name")

    # First document: nothing exists yet to compare against.

    if not existing_name:

        return {"valid": True, "reason": "First document in profile."}

    # Every later document must contain a name for identity checking.

    if not new_name:

        return {

            "valid": False,

            "reason": "Could not identify the person's name in the new document."

        }

    similarity = calculate_name_similarity(existing_name, new_name)

    if similarity is not None and similarity < 0.70:

        return {

            "valid": False,

            "reason": "The name on this document does not match the existing profile.",

            "name_similarity": round(similarity, 2)

        }

    # DOB is checked only when both documents provide it.

    existing_dob = profile_data.get("date_of_birth")

    new_dob = new_data.get("date_of_birth")

    if existing_dob and new_dob and existing_dob != new_dob:

        return {

            "valid": False,

            "reason": "The date of birth does not match the existing profile.",

            "name_similarity": round(similarity, 2) if similarity is not None else None

        }

    return {

        "valid": True,

        "reason": "Document identity matches the profile.",

        "name_similarity": round(similarity, 2) if similarity is not None else None

    }

# =========================================================

# IMAGE PREPROCESSING

# =========================================================

def preprocess_image(image):

    image = ImageOps.exif_transpose(

        image

    )

    image = image.convert(

        "L"

    )

    if image.width < 1800:

        scale = max(

            2,

            int(

                1800 /

                image.width

            )

        )

        image = image.resize(

            (

                image.width * scale,

                image.height * scale

            ),

            Image.Resampling.LANCZOS

        )

    image = ImageEnhance.Contrast(

        image

    ).enhance(

        2.0

    )

    image = image.filter(

        ImageFilter.SHARPEN

    )

    return image

def create_threshold_image(

    image

):

    image = image.convert(

        "L"

    )

    return image.point(

        lambda pixel:

        255

        if pixel > 165

        else 0

    )

# =========================================================

# TEXT NORMALIZATION

# =========================================================

def normalize_text(text):

    text = text.replace(

        "–",

        "-"

    )

    text = text.replace(

        "—",

        "-"

    )

    text = text.replace(

        "−",

        "-"

    )

    text = text.replace(

        "\xa0",

        " "

    )

    return text

# =========================================================

# IMAGE ORIENTATION

# =========================================================

def find_best_orientation(

    image

):

    image = ImageOps.exif_transpose(

        image

    )

    rotations = [

        0,

        90,

        180,

        270

    ]

    keywords = [

        "united arab emirates",

        "identity card",

        "resident identity",

        "id number",

        "name",

        "date of birth",

        "nationality",

        "issuing date",

        "expiry date"

    ]

    best_image = image

    best_text = ""

    best_score = -1

    best_angle = 0

    for angle in rotations:

        if angle == 0:

            rotated = image.copy()

        else:

            rotated = image.rotate(

                angle,

                expand=True

            )

        processed = (

            preprocess_image(

                rotated

            )

        )

        try:

            text = (

                pytesseract

                .image_to_string(

                    processed,

                    config="--psm 11"

                )

            )

        except Exception as error:

            print(

                "ORIENTATION OCR ERROR:",

                error

            )

            continue

        text_lower = (

            text.lower()

        )

        score = sum(

            1

            for keyword

            in keywords

            if keyword in text_lower

        )

        if re.search(

            r"\b784[\s\-]",

            normalize_text(text)

        ):

            score += 3

        print(

            "ORIENTATION:",

            angle,

            "SCORE:",

            score

        )

        if score > best_score:

            best_score = score

            best_image = rotated

            best_text = text

            best_angle = angle

    print(

        "BEST ORIENTATION:",

        best_angle

    )

    print(

        "ORIENTATION SCORE:",

        best_score

    )

    return (

        best_image,

        best_text

    )

# =========================================================

# OCR

# =========================================================

def run_ocr_passes(

    image

):

    texts = []

    processed = (

        preprocess_image(

            image

        )

    )

    thresholded = (

        create_threshold_image(

            processed

        )

    )

    versions = [

        processed,

        thresholded

    ]

    psm_modes = [

        6,

        11

    ]

    for version in versions:

        for psm in psm_modes:

            try:

                text = (

                    pytesseract

                    .image_to_string(

                        version,

                        config=(

                            f"--psm {psm}"

                        )

                    )

                )

                if text.strip():

                    texts.append(

                        normalize_text(

                            text

                        )

                    )

            except Exception as error:

                print(

                    "OCR PASS ERROR:",

                    error

                )

    return texts

# =========================================================

# DOCUMENT TYPE DETECTION

# =========================================================

def detect_document_type(

    text

):

    text_lower = (

        text.lower()

    )

    # -----------------------------------------------------

    # EMIRATES ID

    # -----------------------------------------------------

    emirates_keywords = [

        "united arab emirates",

        "resident identity card",

        "identity card",

        "id number",

        "date of birth",

        "nationality",

        "issuing date",

        "expiry date"

    ]

    emirates_score = sum(

        1

        for keyword

        in emirates_keywords

        if keyword in text_lower

    )

    if re.search(

        r"\b784[\s\-]",

        normalize_text(text)

    ):

        emirates_score += 2

    if emirates_score >= 3:

        return "Emirates ID"

    # -----------------------------------------------------

    # CV

    # -----------------------------------------------------

    cv_keywords = [

        "education",

        "experience",

        "skills",

        "projects"

    ]

    cv_score = sum(

        1

        for keyword

        in cv_keywords

        if keyword in text_lower

    )

    if cv_score >= 3:

        return "CV"

    return "Unknown"

# =========================================================

# GENERIC VOTING

# =========================================================

def choose_most_common(

    candidates

):

    candidates = [

        value

        for value in candidates

        if value

    ]

    if not candidates:

        return None

    counts = Counter(

        candidates

    )

    return (

        counts

        .most_common(1)[0][0]

    )

def choose_with_confidence(

    candidates

):

    candidates = [

        value

        for value in candidates

        if value

    ]

    if not candidates:

        return (

            None,

            0.0

        )

    counts = Counter(

        candidates

    )

    value, votes = (

        counts

        .most_common(1)[0]

    )

    confidence = (

        votes /

        len(candidates)

    )

    return (

        value,

        round(

            confidence,

            2

        )

    )

def choose_best_field(

    texts,

    extractor

):

    candidates = []

    for text in texts:

        result = extractor(

            text

        )

        if result:

            candidates.append(

                result

            )

    return choose_most_common(

        candidates

    )

# =========================================================

# DATE VALIDATION

# =========================================================

def validate_date(

    value

):

    if not value:

        return None

    value = value.replace(

        "-",

        "/"

    )

    try:

        parsed = datetime.strptime(

            value,

            "%d/%m/%Y"

        )

        return parsed.strftime(

            "%d/%m/%Y"

        )

    except ValueError:

        return None

def choose_best_date(

    candidates

):

    valid_candidates = []

    for value in candidates:

        value = validate_date(

            value

        )

        if value:

            valid_candidates.append(

                value

            )

    return choose_with_confidence(

        valid_candidates

    )

# =========================================================

# EMIRATES ID NUMBER

# =========================================================

def extract_emirates_id_number(

    text

):

    text = normalize_text(

        text

    )

    pattern = (

        r"\b784"

        r"\D{1,5}"

        r"(\d{4})"

        r"\D{1,5}"

        r"(\d{7})"

        r"\D{1,5}"

        r"(\d)"

        r"\b"

    )

    match = re.search(

        pattern,

        text

    )

    if match:

        return (

            f"784-"

            f"{match.group(1)}-"

            f"{match.group(2)}-"

            f"{match.group(3)}"

        )

    compact = re.sub(

        r"[^0-9]",

        "",

        text

    )

    match = re.search(

        r"784(\d{4})(\d{7})(\d)",

        compact

    )

    if match:

        return (

            f"784-"

            f"{match.group(1)}-"

            f"{match.group(2)}-"

            f"{match.group(3)}"

        )

    return None

def extract_id_near_label(

    text

):

    text = normalize_text(

        text

    )

    pattern = (

        r"(?:id\s*number|id\s*no)"

        r"[\s\S]{0,100}?"

        r"(784\D{0,5}\d{4}"

        r"\D{0,5}\d{7}"

        r"\D{0,5}\d)"

    )

    match = re.search(

        pattern,

        text,

        re.IGNORECASE

    )

    if not match:

        return None

    digits = re.sub(

        r"\D",

        "",

        match.group(1)

    )

    if len(digits) != 15:

        return None

    if not digits.startswith(

        "784"

    ):

        return None

    return (

        f"{digits[0:3]}-"

        f"{digits[3:7]}-"

        f"{digits[7:14]}-"

        f"{digits[14]}"

    )

def choose_best_id_number(

    texts

):

    candidates = []

    for text in texts:

        near_label = (

            extract_id_near_label(

                text

            )

        )

        normal = (

            extract_emirates_id_number(

                text

            )

        )

        if near_label:

            candidates.append(

                near_label

            )

        if normal:

            candidates.append(

                normal

            )

    print(

        "ID CANDIDATES:",

        Counter(candidates)

    )

    return choose_with_confidence(

        candidates

    )

# =========================================================

# EMIRATES ID NAME

# =========================================================

def extract_name(

    text

):

    patterns = [

        (

            r"\bname\s*[:\-]\s*"

            r"([A-Za-z][A-Za-z .'-]+)"

        ),

        (

            r"\bname\s+"

            r"([A-Za-z][A-Za-z .'-]+)"

        )

    ]

    for pattern in patterns:

        match = re.search(

            pattern,

            text,

            re.IGNORECASE

        )

        if not match:

            continue

        name = (

            match.group(1)

        )

        name = name.split(

            "\n"

        )[0]

        name = re.sub(

            r"\s+",

            " ",

            name

        )

        name = name.strip(

            " .:-"

        )

        if (

            3 <=

            len(name) <=

            100

        ):

            return name

    return None

def choose_best_name(

    texts

):

    candidates = []

    for text in texts:

        name = extract_name(

            text

        )

        if name:

            candidates.append(

                name

            )

    if not candidates:

        return None

    counts = Counter(

        candidates

    )

    best_name, votes = (

        counts

        .most_common(1)[0]

    )

    if votes >= 2:

        return best_name

    reasonable = [

        name

        for name

        in candidates

        if (

            2 <=

            len(name.split()) <=

            8

            and

            len(name) <= 80

        )

    ]

    if reasonable:

        return min(

            reasonable,

            key=len

        )

    return best_name

# =========================================================

# EMIRATES ID DATES

# =========================================================

def extract_date_after_label(

    text,

    labels,

    distance=60

):

    label_pattern = "|".join(

        labels

    )

    pattern = (

        rf"(?:{label_pattern})"

        rf"[\s\S]{{0,{distance}}}?"

        r"(\d{1,2}[/-]\d{1,2}[/-]\d{4})"

    )

    match = re.search(

        pattern,

        text,

        re.IGNORECASE

    )

    if not match:

        return None

    return validate_date(

        match.group(1)

    )

def extract_date_of_birth(

    text

):

    return extract_date_after_label(

        text,

        [

            r"date\s*of\s*birth",

            r"birth\s*date"

        ],

        60

    )

def extract_issue_date(

    text

):

    return extract_date_after_label(

        text,

        [

            r"issuing\s*date",

            r"issue\s*date"

        ],

        70

    )

def extract_expiry_date(

    text

):

    return extract_date_after_label(

        text,

        [

            r"expiry\s*date",

            r"expiration\s*date"

        ],

        70

    )

# =========================================================

# NATIONALITY

# =========================================================

def extract_nationality(

    text

):

    pattern = (

        r"\bnationality"

        r"\s*[:\-]?\s*"

        r"([A-Za-z]+(?:\s+[A-Za-z]+)?)"

    )

    match = re.search(

        pattern,

        text,

        re.IGNORECASE

    )

    if not match:

        return None

    nationality = (

        match

        .group(1)

        .strip()

    )

    stop_words = {

        "issuing",

        "issue",

        "expiry",

        "expiration",

        "date",

        "sex",

        "signature"

    }

    words = []

    for word in nationality.split():

        if word.lower() in stop_words:

            break

        words.append(

            word

        )

    result = " ".join(

        words

    )

    return (

        result

        if result

        else None

    )

# =========================================================

# EMIRATES ID FIELD EXTRACTION

# =========================================================

def extract_emirates_id_fields(

    ocr_texts

):

    (

        document_number,

        id_confidence

    ) = choose_best_id_number(

        ocr_texts

    )

    name = choose_best_name(

        ocr_texts

    )

    nationality = (

        choose_best_field(

            ocr_texts,

            extract_nationality

        )

    )

    # DOB

    dob_candidates = [

        extract_date_of_birth(

            text

        )

        for text

        in ocr_texts

    ]

    (

        date_of_birth,

        dob_confidence

    ) = choose_best_date(

        dob_candidates

    )

    # ISSUE DATE

    issue_candidates = [

        extract_issue_date(

            text

        )

        for text

        in ocr_texts

    ]

    (

        issue_date,

        issue_confidence

    ) = choose_best_date(

        issue_candidates

    )

    # EXPIRY DATE

    expiry_candidates = [

        extract_expiry_date(

            text

        )

        for text

        in ocr_texts

    ]

    (

        expiry_date,

        expiry_confidence

    ) = choose_best_date(

        expiry_candidates

    )

    print(

        "DOB CANDIDATES:",

        dob_candidates

    )

    print(

        "ISSUE CANDIDATES:",

        issue_candidates

    )

    print(

        "EXPIRY CANDIDATES:",

        expiry_candidates

    )

    values = {

        "name":

            name,

        "document_number":

            document_number,

        "date_of_birth":

            date_of_birth,

        "nationality":

            nationality,

        "issue_date":

            issue_date,

        "expiry_date":

            expiry_date

    }

    missing_fields = [

        field

        for field, value

        in values.items()

        if not value

    ]

    return {

        **values,

        "id_confidence":

            id_confidence,

        "dob_confidence":

            dob_confidence,

        "issue_confidence":

            issue_confidence,

        "expiry_confidence":

            expiry_confidence,

        "missing_fields":

            missing_fields

    }

# =========================================================

# CV

# =========================================================

def extract_email(

    text

):

    pattern = (

        r"\b[A-Za-z0-9._%+-]+"

        r"@[A-Za-z0-9.-]+"

        r"\.[A-Za-z]{2,}\b"

    )

    match = re.search(

        pattern,

        text

    )

    if match:

        return match.group()

    return None

def extract_phone_number(

    text

):

    pattern = (

        r"(?:\+?\d{1,3}[\s.-]?)?"

        r"(?:\(?\d{2,4}\)?[\s.-]?)?"

        r"\d{3}[\s.-]?\d{4}"

    )

    match = re.search(

        pattern,

        text

    )

    if match:

        return (

            match

            .group()

            .strip()

        )

    return None

def extract_cv_name(

    text

):

    lines = (

        text.splitlines()

    )

    for line in lines:

        line = line.strip()

        if line:

            return line.title()

    return None

def extract_cv_section(

    text,

    heading,

    next_headings

):

    next_pattern = "|".join(

        next_headings

    )

    pattern = (

        rf"(?:{heading})\s*"

        rf"([\s\S]*?)"

        rf"(?=\n\s*(?:{next_pattern})\b|$)"

    )

    match = re.search(

        pattern,

        text,

        re.IGNORECASE

    )

    if match:

        return (

            match

            .group(1)

            .strip()

        )

    return None

def extract_cv_skills(

    text

):

    return extract_cv_section(

        text,

        r"technical\s+skills|skills",

        [

            "education",

            "experience",

            "projects",

            "certifications",

            "languages"

        ]

    )

def extract_cv_education(

    text

):

    return extract_cv_section(

        text,

        "education",

        [

            "experience",

            "projects",

            "skills",

            r"technical\s+skills",

            "certifications",

            "languages"

        ]

    )

def extract_cv_experience(

    text

):

    return extract_cv_section(

        text,

        (

            r"work\s+experience|"

            r"professional\s+experience|"

            r"experience"

        ),

        [

            "education",

            "projects",

            "skills",

            r"technical\s+skills",

            "certifications",

            "languages"

        ]

    )

def extract_cv_projects(

    text

):

    return extract_cv_section(

        text,

        "projects",

        [

            "education",

            "experience",

            "skills",

            r"technical\s+skills",

            "certifications",

            "languages"

        ]

    )

def extract_cv_fields(

    text

):

    return {

        "name":

            extract_cv_name(

                text

            ),

        "email":

            extract_email(

                text

            ),

        "phone_number":

            extract_phone_number(

                text

            ),

        "skills":

            extract_cv_skills(

                text

            ),

        "education":

            extract_cv_education(

                text

            ),

        "experience":

            extract_cv_experience(

                text

            ),

        "projects":

            extract_cv_projects(

                text

            )

    }

# =========================================================

# LOCAL EXTRACTION ONLY

# No cloud/API extraction is used in this prototype.
# PDFs use pypdf text extraction and images use Tesseract OCR.

# =========================================================

# PDF READING

# =========================================================

def read_pdf(

    contents

):

    text = ""

    try:

        pdf = PdfReader(

            BytesIO(

                contents

            )

        )

        for page in pdf.pages:

            page_text = (

                page.extract_text()

            )

            if page_text:

                text += (

                    page_text +

                    "\n"

                )

    except Exception as error:

        print(

            "PDF ERROR:",

            error

        )

        raise HTTPException(

            status_code=400,

            detail="Could not read PDF."

        )

    if not text.strip():

        raise HTTPException(

            status_code=400,

            detail=(

                "No readable text was found "

                "in this PDF."

            )

        )

    return text

# =========================================================

# IMAGE READING

# =========================================================

def read_image(

    contents

):

    try:

        image = Image.open(

            BytesIO(

                contents

            )

        )

        (

            oriented_image,

            orientation_text

        ) = find_best_orientation(

            image

        )

        ocr_texts = (

            run_ocr_passes(

                oriented_image

            )

        )

        if orientation_text.strip():

            ocr_texts.append(

                normalize_text(

                    orientation_text

                )

            )

        if not ocr_texts:

            raise HTTPException(

                status_code=400,

                detail=(

                    "No readable text was "

                    "found in this image."

                )

            )

        return (

            oriented_image,

            ocr_texts

        )

    except HTTPException:

        raise

    except Exception as error:

        print(

            "IMAGE OCR ERROR:",

            error

        )

        raise HTTPException(

            status_code=400,

            detail="Could not read image."

        )

# =========================================================

# UPLOAD

# =========================================================

@app.post("/upload")
async def upload_document(
    file: UploadFile = File(...),
    expected_type: str = Form(...)
):
    allowed_types = {"emirates_id", "cv"}

    if expected_type not in allowed_types:
        raise HTTPException(
            status_code=400,
            detail="Invalid expected document type."
        )

    contents = await file.read(15 * 1024 * 1024 + 1)
    if len(contents) > 15 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="The maximum file size is 15 MB.")

    if not contents:
        raise HTTPException(
            status_code=400,
            detail="The uploaded file is empty."
        )

    text = ""
    ocr_texts = []

    # -----------------------------------------------------
    # LOCAL FILE READING
    # -----------------------------------------------------

    if file.content_type in {"image/jpeg", "image/png"}:
        try:
            pytesseract.get_tesseract_version()
        except Exception:
            raise HTTPException(503, "Tesseract OCR was not found. Install it locally or set TESSERACT_CMD, then restart the server.")
        _, ocr_texts = read_image(contents)
        text = "\n".join(ocr_texts)

    elif file.content_type == "application/pdf":
        text = read_pdf(contents)
        ocr_texts = [text]

    else:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Use PDF, JPG, JPEG or PNG."
        )

    # -----------------------------------------------------
    # DOCUMENT TYPE CHECK
    # -----------------------------------------------------

    document_type = detect_document_type(text)
    detected_type = document_type.lower().replace(" ", "_")

    if detected_type != expected_type:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Wrong document. Expected {expected_type}, "
                f"but detected {detected_type}."
            )
        )

    # -----------------------------------------------------
    # DEFAULT RESULT
    # -----------------------------------------------------

    result = {
        "filename": file.filename,
        "content_type": file.content_type,
        "document_type": document_type,
        "expected_type": expected_type,
        "name": None,
        "document_number": None,
        "date_of_birth": None,
        "nationality": None,
        "issue_date": None,
        "expiry_date": None,
        "email": None,
        "phone_number": None,
        "skills": None,
        "education": None,
        "experience": None,
        "projects": None,
        "id_confidence": 0.0,
        "dob_confidence": 0.0,
        "issue_confidence": 0.0,
        "expiry_confidence": 0.0,
        "extraction_status": "complete",
        "missing_fields": [],
        "text": text,
        "extraction_method": "local"
    }

    # -----------------------------------------------------
    # LOCAL FIELD EXTRACTION
    # -----------------------------------------------------

    if document_type == "Emirates ID":
        fields = extract_emirates_id_fields(ocr_texts)
        result.update(fields)
        result["extraction_method"] = "tesseract_local"

        if fields["missing_fields"]:
            result["extraction_status"] = "review_required"

    elif document_type == "CV":
        fields = extract_cv_fields(text)
        result.update(fields)
        result["extraction_method"] = (
            "pdf_text_local"
            if file.content_type == "application/pdf"
            else "tesseract_local"
        )

        required_fields = {
            "name": fields["name"],
            "email": fields["email"],
            "phone_number": fields["phone_number"]
        }

        missing = [
            field
            for field, value in required_fields.items()
            if not value
        ]

        result["missing_fields"] = missing

        if missing:
            result["extraction_status"] = "review_required"

    return result

# =========================================================

# CONFIRM DOCUMENT

#

# profile_id is OPTIONAL.

#

# Old frontend:

#   Works normally.

#

# New frontend later:

#   Sends profile_id and the document gets merged into

#   that profile.

# =========================================================

@app.post("/confirm")

async def confirm_document(

    data: dict

):

    document_id = str(

        uuid.uuid4()

    )

    document_type = data.get(

        "document_type"

    )

    profile_id = data.get(

        "profile_id"

    )

    if document_type not in {

        "Emirates ID",

        "CV"

    }:

        raise HTTPException(

            status_code=400,

            detail="Invalid document type."

        )

    connection = get_database()

    try:

        # -------------------------------------------------

        # SAVE CONFIRMED DOCUMENT

        # -------------------------------------------------

        connection.execute(

            """

            INSERT INTO documents (

                id,

                document_type,

                filename,

                name,

                document_number,

                date_of_birth,

                nationality,

                issue_date,

                expiry_date,

                email,

                phone_number,

                skills,

                education,

                experience,

                projects

            )

            VALUES (

                ?, ?, ?,

                ?, ?, ?, ?, ?, ?,

                ?, ?, ?, ?, ?, ?

            )

            """,

            (

                document_id,

                document_type,

                data.get("filename"),

                data.get("name"),

                data.get("document_number"),

                data.get("date_of_birth"),

                data.get("nationality"),

                data.get("issue_date"),

                data.get("expiry_date"),

                data.get("email"),

                data.get("phone_number"),

                data.get("skills"),

                data.get("education"),

                data.get("experience"),

                data.get("projects")

            )

        )

        # -------------------------------------------------

        # CONNECT TO PROFILE

        # -------------------------------------------------

        if profile_id:

            profile = (

                connection.execute(

                    """

                    SELECT id

                    FROM profiles

                    WHERE id = ?

                    """,

                    (

                        profile_id,

                    )

                ).fetchone()

            )

            if not profile:

                raise HTTPException(

                    status_code=404,

                    detail="Profile not found."

                )

            # ---------------------------------------------

            # VALIDATE THAT BOTH DOCUMENTS BELONG TO

            # THE SAME PERSON BEFORE ATTACHING/MERGING

            # ---------------------------------------------

            identity_check = validate_document_identity(

                connection,

                profile_id,

                data

            )

            if not identity_check["valid"]:

                raise HTTPException(

                    status_code=409,

                    detail=identity_check["reason"]

                )

            connection.execute(

                """

                INSERT INTO profile_documents (

                    id,

                    profile_id,

                    document_id

                )

                VALUES (?, ?, ?)

                """,

                (

                    str(

                        uuid.uuid4()

                    ),

                    profile_id,

                    document_id

                )

            )

            # ---------------------------------------------

            # MERGE CONFIRMED DATA INTO PROFILE

            # ---------------------------------------------

            merge_document_into_profile(

                connection,

                profile_id,

                data

            )

        connection.commit()

        # Keep the Excel Profiles sheet synchronized with confirmed profile data.
        try:
            sync_profiles_to_excel()
        except PermissionError:
            print(
                "EXCEL WARNING: applications.xlsx is open. "
                "Profile was saved to SQLite, but Excel was not updated."
            )
        except Exception as error:
            print("PROFILE EXCEL WARNING:", error)

    except HTTPException:

        connection.rollback()

        raise

    except Exception as error:

        connection.rollback()

        print(

            "DATABASE SAVE ERROR:",

            error

        )

        raise HTTPException(

            status_code=500,

            detail=(

                "Could not save confirmed "

                "information."

            )

        )

    finally:

        connection.close()

    return {

        "message":

            "Information confirmed successfully.",

        "document_id":

            document_id,

        "profile_id":

            profile_id

    }

# =========================================================

# DOCUMENTS

# =========================================================

@app.get("/documents")

def get_documents():

    connection = get_database()

    try:

        rows = connection.execute(

            """

            SELECT *

            FROM documents

            ORDER BY created_at DESC

            """

        ).fetchall()

    finally:

        connection.close()

    return [

        dict(row)

        for row in rows

    ]

@app.get(

    "/documents/{document_id}"

)

def get_document(

    document_id: str

):

    connection = get_database()

    try:

        document = (

            connection.execute(

                """

                SELECT *

                FROM documents

                WHERE id = ?

                """,

                (

                    document_id,

                )

            ).fetchone()

        )

    finally:

        connection.close()

    if not document:

        raise HTTPException(

            status_code=404,

            detail="Document not found."

        )

    return dict(

        document

    )

# =========================================================

# CREATE PROFILE

# =========================================================

@app.post("/profiles")

def create_profile():

    profile_id = str(

        uuid.uuid4()

    )

    connection = get_database()

    try:

        connection.execute(

            """

            INSERT INTO profiles (

                id

            )

            VALUES (?)

            """,

            (

                profile_id,

            )

        )

        connection.commit()

        # Add the new profile to the Excel Profiles sheet immediately.
        try:
            sync_profiles_to_excel()
        except PermissionError:
            print(
                "EXCEL WARNING: applications.xlsx is open. "
                "Profile was created in SQLite, but Excel was not updated."
            )
        except Exception as error:
            print("PROFILE EXCEL WARNING:", error)

    except Exception as error:

        connection.rollback()

        print(

            "PROFILE CREATE ERROR:",

            error

        )

        raise HTTPException(

            status_code=500,

            detail=(

                "Could not create profile."

            )

        )

    finally:

        connection.close()

    return {

        "message":

            "Profile created successfully.",

        "profile_id":

            profile_id

    }

# =========================================================

# GET ALL PROFILES

# =========================================================

@app.get("/profiles")

def get_profiles():

    connection = get_database()

    try:

        profiles = (

            connection.execute(

                """

                SELECT *

                FROM profiles

                ORDER BY created_at DESC

                """

            ).fetchall()

        )

    finally:

        connection.close()

    return [

        dict(profile)

        for profile

        in profiles

    ]

# =========================================================
# SEARCH PROFILES
# =========================================================

@app.get("/profiles/search")
def search_profiles(q: str = ""):
    query = normalize_person_name(q)
    if not query:
        return []

    connection = get_database()
    try:
        rows = connection.execute(
            """
            SELECT * FROM profiles
            WHERE name IS NOT NULL AND TRIM(name) != ''
            ORDER BY updated_at DESC
            """
        ).fetchall()
    finally:
        connection.close()

    matches = []
    for row in rows:
        profile = dict(row)
        name = normalize_person_name(profile.get("name"))
        if not name:
            continue

        # Strong partial/word match first, fuzzy similarity second.
        words = name.split()
        partial = query in name or any(word.startswith(query) for word in words)
        similarity = SequenceMatcher(None, query, name).ratio()
        word_similarity = max(
            [SequenceMatcher(None, query, word).ratio() for word in words] or [0]
        )
        score = max(similarity, word_similarity)

        if partial or score >= 0.45:
            profile["match_score"] = round(1.0 if partial else score, 3)
            matches.append(profile)

    matches.sort(
        key=lambda item: (
            item.get("match_score", 0),
            item.get("updated_at") or ""
        ),
        reverse=True
    )
    return matches[:8]

# =========================================================
# UPDATE PROFILE
# =========================================================

@app.put("/profiles/{profile_id}")
def update_profile(profile_id: str, data: dict):
    allowed_fields = [
        "name", "email", "phone_number", "document_number",
        "date_of_birth", "nationality", "issue_date", "expiry_date",
        "skills", "education", "experience", "projects"
    ]

    connection = get_database()
    try:
        existing = connection.execute(
            "SELECT id FROM profiles WHERE id = ?",
            (profile_id,)
        ).fetchone()

        if not existing:
            raise HTTPException(status_code=404, detail="Profile not found.")

        values = []
        assignments = []
        for field in allowed_fields:
            if field in data:
                value = data.get(field)
                if isinstance(value, str):
                    value = value.strip() or None
                assignments.append(f"{field} = ?")
                values.append(value)

        if assignments:
            assignments.append("updated_at = CURRENT_TIMESTAMP")
            values.append(profile_id)
            connection.execute(
                f"UPDATE profiles SET {', '.join(assignments)} WHERE id = ?",
                values
            )
            connection.commit()

        updated = connection.execute(
            "SELECT * FROM profiles WHERE id = ?",
            (profile_id,)
        ).fetchone()

    except HTTPException:
        connection.rollback()
        raise
    except Exception as error:
        connection.rollback()
        print("PROFILE UPDATE ERROR:", error)
        raise HTTPException(status_code=500, detail="Could not update profile.")
    finally:
        connection.close()

    excel_saved = True
    try:
        sync_profiles_to_excel()
    except PermissionError:
        excel_saved = False
    except Exception as error:
        excel_saved = False
        print("PROFILE EXCEL WARNING:", error)

    return {
        "message": "Profile updated successfully.",
        "profile": dict(updated),
        "excel_saved": excel_saved
    }

# =========================================================

# GET ONE PROFILE

# =========================================================

@app.get(

    "/profiles/{profile_id}"

)

def get_profile(

    profile_id: str

):

    connection = get_database()

    try:

        profile = (

            connection.execute(

                """

                SELECT *

                FROM profiles

                WHERE id = ?

                """,

                (

                    profile_id,

                )

            ).fetchone()

        )

    finally:

        connection.close()

    if not profile:

        raise HTTPException(

            status_code=404,

            detail="Profile not found."

        )

    return dict(

        profile

    )

# =========================================================

# GET PROFILE DOCUMENTS

# =========================================================

@app.get(

    "/profiles/{profile_id}/documents"

)

def get_profile_documents(

    profile_id: str

):

    connection = get_database()

    try:

        profile = (

            connection.execute(

                """

                SELECT id

                FROM profiles

                WHERE id = ?

                """,

                (

                    profile_id,

                )

            ).fetchone()

        )

        if not profile:

            raise HTTPException(

                status_code=404,

                detail="Profile not found."

            )

        documents = (

            connection.execute(

                """

                SELECT documents.*

                FROM documents

                INNER JOIN profile_documents

                    ON documents.id =

                    profile_documents.document_id

                WHERE

                    profile_documents.profile_id = ?

                ORDER BY

                    documents.created_at DESC

                """,

                (

                    profile_id,

                )

            ).fetchall()

        )

    finally:

        connection.close()

    return [

        dict(document)

        for document

        in documents

    ]

# =========================================================

# PROFILE SUMMARY

#

# Useful for the frontend later.

# Returns both the combined profile and its documents.

# =========================================================

@app.get(

    "/profiles/{profile_id}/summary"

)

def get_profile_summary(

    profile_id: str

):

    connection = get_database()

    try:

        profile = (

            connection.execute(

                """

                SELECT *

                FROM profiles

                WHERE id = ?

                """,

                (

                    profile_id,

                )

            ).fetchone()

        )

        if not profile:

            raise HTTPException(

                status_code=404,

                detail="Profile not found."

            )

        documents = (

            connection.execute(

                """

                SELECT

                    documents.id,

                    documents.document_type,

                    documents.filename,

                    documents.created_at

                FROM documents

                INNER JOIN profile_documents

                    ON documents.id =

                    profile_documents.document_id

                WHERE

                    profile_documents.profile_id = ?

                ORDER BY

                    documents.created_at DESC

                """,

                (

                    profile_id,

                )

            ).fetchall()

        )

    finally:

        connection.close()

    return {

        "profile":

            dict(profile),

        "documents": [

            dict(document)

            for document

            in documents

        ]

    }

# =========================================================
# APPLICATIONS / EXCEL EXPORT
# =========================================================

EXCEL_PATH = Path(os.environ.get("DOCUMENT_EXCEL", str(BASE_DIR / "applications.xlsx")))

EXCEL_HEADERS = [
    "Application ID",
    "Profile ID",
    "Full Name",
    "Date of Birth",
    "Nationality",
    "Email",
    "Phone Number",
    "Emirates ID",
    "Issue Date",
    "Expiry Date",
    "Education",
    "Skills",
    "Experience",
    "Projects",
    "Submitted At"
]

def style_application_worksheet(worksheet):
    for cell in worksheet[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="D9EAD3")
        cell.alignment = Alignment(horizontal="center")

    worksheet.freeze_panes = "A2"
    worksheet.auto_filter.ref = worksheet.dimensions

    widths = {
        "A": 38,
        "B": 38,
        "C": 28,
        "D": 16,
        "E": 18,
        "F": 30,
        "G": 20,
        "H": 22,
        "I": 16,
        "J": 16,
        "K": 35,
        "L": 35,
        "M": 45,
        "N": 45,
        "O": 22
    }

    for column, width in widths.items():
        worksheet.column_dimensions[column].width = width

    for row in worksheet.iter_rows(min_row=2):
        for cell in row:
            if isinstance(cell.value, str):
                cell.data_type = "s"
            cell.alignment = Alignment(
                vertical="top",
                wrap_text=True
            )

def append_application_to_excel(application_id, profile_id, data):
    if EXCEL_PATH.exists():
        workbook = load_workbook(EXCEL_PATH)

        if "Applications" in workbook.sheetnames:
            worksheet = workbook["Applications"]
        else:
            worksheet = workbook.create_sheet("Applications")
            worksheet.append(EXCEL_HEADERS)
    else:
        workbook = Workbook()
        worksheet = workbook.active
        worksheet.title = "Applications"
        worksheet.append(EXCEL_HEADERS)

    submitted_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    worksheet.append([
        application_id,
        profile_id,
        data.get("full_name"),
        data.get("date_of_birth"),
        data.get("nationality"),
        data.get("email"),
        data.get("phone_number"),
        data.get("document_number"),
        data.get("issue_date"),
        data.get("expiry_date"),
        data.get("education"),
        data.get("skills"),
        data.get("experience"),
        data.get("projects"),
        submitted_at
    ])

    style_application_worksheet(worksheet)
    workbook.save(EXCEL_PATH)

def sync_applications_to_excel():
    """Rebuild applications.xlsx from SQLite."""

    connection = get_database()

    try:
        applications = connection.execute(
            """
            SELECT *
            FROM applications
            ORDER BY submitted_at ASC
            """
        ).fetchall()
    finally:
        connection.close()

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "Applications"
    worksheet.append(EXCEL_HEADERS)

    for application in applications:
        worksheet.append([
            application["id"],
            application["profile_id"],
            application["full_name"],
            application["date_of_birth"],
            application["nationality"],
            application["email"],
            application["phone_number"],
            application["document_number"],
            application["issue_date"],
            application["expiry_date"],
            application["education"],
            application["skills"],
            application["experience"],
            application["projects"],
            application["submitted_at"]
        ])

    style_application_worksheet(worksheet)
    workbook.save(EXCEL_PATH)

    return len(applications)

PROFILE_HEADERS = [
    "Profile ID",
    "Full Name",
    "Date of Birth",
    "Nationality",
    "Email",
    "Phone Number",
    "Emirates ID",
    "Issue Date",
    "Expiry Date",
    "Education",
    "Skills",
    "Experience",
    "Projects",
    "Created At",
    "Updated At"
]

def sync_profiles_to_excel():
    """Create/update one Excel row per profile using SQLite as the source of truth."""
    connection = get_database()
    try:
        profiles = connection.execute(
            """
            SELECT *
            FROM profiles
            ORDER BY created_at ASC
            """
        ).fetchall()
    finally:
        connection.close()

    if EXCEL_PATH.exists():
        workbook = load_workbook(EXCEL_PATH)
    else:
        workbook = Workbook()
        default_sheet = workbook.active
        workbook.remove(default_sheet)

    if "Profiles" in workbook.sheetnames:
        old_sheet = workbook["Profiles"]
        sheet_index = workbook.sheetnames.index("Profiles")
        workbook.remove(old_sheet)
        worksheet = workbook.create_sheet("Profiles", sheet_index)
    else:
        worksheet = workbook.create_sheet("Profiles", 0)

    worksheet.append(PROFILE_HEADERS)

    for profile in profiles:
        worksheet.append([
            profile["id"],
            profile["name"],
            profile["date_of_birth"],
            profile["nationality"],
            profile["email"],
            profile["phone_number"],
            profile["document_number"],
            profile["issue_date"],
            profile["expiry_date"],
            profile["education"],
            profile["skills"],
            profile["experience"],
            profile["projects"],
            profile["created_at"],
            profile["updated_at"]
        ])

    style_application_worksheet(worksheet)
    workbook.save(EXCEL_PATH)
    return len(profiles)

@app.post("/applications")
async def submit_application(data: dict):
    if not isinstance(data.get("full_name"), str) or not data["full_name"].strip():
        raise HTTPException(status_code=400, detail="Full name is required.")
    if data.get("email") and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", str(data["email"])):
        raise HTTPException(status_code=400, detail="Enter a valid email address.")
    application_id = str(uuid.uuid4())
    profile_id = data.get("profile_id")

    if not profile_id:
        raise HTTPException(status_code=400, detail="Profile ID is required.")

    connection = get_database()
    excel_saved = False

    try:
        profile = connection.execute(
            "SELECT id FROM profiles WHERE id = ?",
            (profile_id,)
        ).fetchone()

        if not profile:
            raise HTTPException(status_code=404, detail="Profile not found.")

        # One submitted application per profile.
        existing = connection.execute(
            """
            SELECT id
            FROM applications
            WHERE profile_id = ?
            ORDER BY submitted_at ASC
            LIMIT 1
            """,
            (profile_id,)
        ).fetchone()

        if existing:
            return {
                "message": "This profile has already submitted an application.",
                "application_id": existing["id"],
                "profile_id": profile_id,
                "duplicate": True,
                "excel_saved": None
            }

        connection.execute(
            """
            INSERT INTO applications (
                id, profile_id, full_name, date_of_birth, nationality,
                email, phone_number, document_number, issue_date, expiry_date,
                education, skills, experience, projects
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                application_id, profile_id, data.get("full_name"),
                data.get("date_of_birth"), data.get("nationality"),
                data.get("email"), data.get("phone_number"),
                data.get("document_number"), data.get("issue_date"),
                data.get("expiry_date"), data.get("education"),
                data.get("skills"), data.get("experience"),
                data.get("projects")
            )
        )

        connection.execute("DELETE FROM application_drafts WHERE profile_id=?", (profile_id,))
        connection.commit()

        try:
            # Rebuild from SQLite so previously missed Excel rows are restored too.
            sync_applications_to_excel()
            excel_saved = True
        except PermissionError:
            print(
                "EXCEL WARNING: applications.xlsx is open. "
                "Application was saved to SQLite, but Excel was not updated."
            )
        except Exception as error:
            print("EXCEL WARNING:", error)

    except HTTPException:
        connection.rollback()
        raise
    except Exception as error:
        connection.rollback()
        print("APPLICATION SAVE ERROR:", error)
        raise HTTPException(status_code=500, detail="Could not submit application.")
    finally:
        connection.close()

    return {
        "message": "Application submitted successfully.",
        "application_id": application_id,
        "profile_id": profile_id,
        "duplicate": False,
        "excel_saved": excel_saved
    }

@app.get("/applications")
def get_applications():
    connection = get_database()

    try:
        rows = connection.execute(
            """
            SELECT *
            FROM applications
            ORDER BY submitted_at DESC
            """
        ).fetchall()
    finally:
        connection.close()

    return [dict(row) for row in rows]

@app.post("/applications/sync-excel")
async def sync_excel():
    try:
        applications_total = sync_applications_to_excel()
        profiles_total = sync_profiles_to_excel()

        return {
            "message": "Excel synchronized successfully.",
            "profiles_exported": profiles_total,
            "applications_exported": applications_total
        }

    except PermissionError:
        raise HTTPException(
            status_code=409,
            detail=(
                "applications.xlsx is currently open. "
                "Close Excel and try again."
            )
        )

    except Exception as error:
        print(
            "EXCEL SYNC ERROR:",
            error
        )

        raise HTTPException(
            status_code=500,
            detail="Could not synchronize Excel."
        )

# =========================================================
# DELETE PROFILE
# =========================================================

@app.delete("/profiles/{profile_id}")
def delete_profile(profile_id: str):
    connection = get_database()
    try:
        profile = connection.execute(
            "SELECT id, name FROM profiles WHERE id = ?",
            (profile_id,)
        ).fetchone()
        if not profile:
            raise HTTPException(status_code=404, detail="Profile not found.")

        document_rows = connection.execute(
            "SELECT document_id FROM profile_documents WHERE profile_id = ?",
            (profile_id,)
        ).fetchall()
        document_ids = [row["document_id"] for row in document_rows]

        connection.execute("DELETE FROM profiles WHERE id = ?", (profile_id,))

        # Remove documents that are no longer attached to any profile.
        for document_id in document_ids:
            still_used = connection.execute(
                "SELECT 1 FROM profile_documents WHERE document_id = ? LIMIT 1",
                (document_id,)
            ).fetchone()
            if not still_used:
                connection.execute("DELETE FROM documents WHERE id = ?", (document_id,))

        connection.commit()
    except HTTPException:
        connection.rollback()
        raise
    except Exception as error:
        connection.rollback()
        print("PROFILE DELETE ERROR:", error)
        raise HTTPException(status_code=500, detail="Could not delete profile.")
    finally:
        connection.close()

    excel_saved = True
    try:
        sync_profiles_to_excel()
        sync_applications_to_excel()
    except PermissionError:
        excel_saved = False
    except Exception as error:
        excel_saved = False
        print("PROFILE DELETE EXCEL WARNING:", error)

    return {
        "message": "Profile deleted successfully.",
        "profile_id": profile_id,
        "excel_saved": excel_saved
    }

# =========================================================

# FRONTEND

#

# IMPORTANT:

# THIS MUST STAY AT THE BOTTOM.

# =========================================================

from backend.workspace import install_workspace
install_workspace(app, get_database, user_from_request, hash_password, BASE_DIR)
from backend.operations import install_operations
install_operations(app, get_database, user_from_request)

app.mount(

    "/app",

    StaticFiles(

        directory=str(BASE_DIR / "frontend"),

        html=True

    ),

    name="frontend"

)