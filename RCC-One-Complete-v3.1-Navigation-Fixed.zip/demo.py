"""Launch isolated fictional demo. Never opens the supplied employee database."""
import os
import secrets
import sqlite3
import webbrowser
from pathlib import Path
from datetime import date, timedelta
BASE=Path(__file__).resolve().parent
os.chdir(BASE)
os.environ['DOCUMENT_DB']=str(BASE/'rcc_demo.db')
os.environ['DOCUMENT_EXCEL']=str(BASE/'rcc_demo_applications.xlsx')
os.environ['RCC_DEMO']='1'
from backend import main

def seed():
    with main.get_database() as c:
        if not c.execute('SELECT 1 FROM ops_projects').fetchone():
            projects=[('Al Waha Learning Campus','Education','Al Ain · Demo site','Demo PM A',28500000,68,90),('Coastal Health Centre','Healthcare','Abu Dhabi · Demo site','Demo PM B',19200000,42,160),('Garden Villas · Phase II','Residential','Dubai · Demo site','Demo PM C',46700000,31,220),('Civic Services Annex','Government','Al Ain · Demo site','Demo PM D',12800000,86,35)]
            for name,sector,loc,pm,budget,progress,days in projects:
                c.execute('INSERT INTO ops_projects(name,sector,location,manager,budget,due,progress) VALUES(?,?,?,?,?,?,?)',(name,sector,loc,pm,budget,str(date.today()+timedelta(days=days)),progress))
            rows=[(1,'procurement','Reinforcement steel · Zone B','Demo Procurement Lead','high',-2,385000,'Confirm specification and delivery window.','in_review'),(2,'qhse','Close temporary access barrier gap','Demo Safety Officer','critical',-1,0,'Corrective action: secure edge protection, inspect and record completion.','open'),(3,'rfi','Clarify drainage invert levels','Demo Design Coordinator','high',2,0,'Civil drawings require coordinated invert levels before excavation.','in_review'),(1,'submittal','Classroom ceiling finish sample','Demo Architect','normal',4,0,'Material review against the project finish schedule.','open'),(4,'permit','Authority inspection readiness','Demo Site Engineer','high',3,0,'Confirm inspection checklist and appointment request.','in_review'),(2,'procurement','Air handling equipment package','Demo MEP Lead','normal',12,720000,'Approved demonstration commitment; no purchase order is sent.','approved'),(3,'variation','Additional boundary wall scope','Demo Quantity Surveyor','normal',8,195000,'Demonstration estimate awaiting scope review.','in_review'),(4,'procurement','Final landscaping package','Demo Procurement Lead','normal',-4,142000,'Demonstration completed request.','closed')]
            for pid,kind,title,owner,priority,days,amount,detail,status in rows:
                ident=c.execute('INSERT INTO ops_items(project_id,kind,title,owner,priority,due,amount,detail,status) VALUES(?,?,?,?,?,?,?,?,?)',(pid,kind,title,owner,priority,str(date.today()+timedelta(days=days)),amount,detail,status)).lastrowid
                c.execute('INSERT INTO ops_history(item_id,actor,status,note) VALUES(?,?,?,?)',(ident,'Demo scenario',status,'Fictional initial scenario for supervisor walkthrough.'))
            c.execute('INSERT INTO ops_daily(project_id,day,manpower,hours,work,blockers,actor) VALUES(?,?,?,?,?,?,?)',(1,str(date.today()),84,8,'Completed first-floor slab preparation in Zone A. Coordinated MEP sleeves before inspection.','Zone B reinforcement delivery pending review.','Demo Site Engineer'))
        password=secrets.token_urlsafe(12)
        c.execute("DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE email='demo@rcc.local')")
        c.execute("INSERT INTO users(id,full_name,email,password_hash,role) VALUES('demo-admin','Demo Supervisor','demo@rcc.local',?,'authorized') ON CONFLICT(email) DO UPDATE SET password_hash=excluded.password_hash",(main.hash_password(password),))
        return password

if __name__=='__main__':
    password=seed()
    print('\nRCC ONE — LOCAL FICTIONAL DEMO\nOpen http://127.0.0.1:8000\nAdmin email: demo@rcc.local\nSession password: '+password+'\nPassword changes each time this launcher starts.\n',flush=True)
    import uvicorn
    uvicorn.run(main.app,host='127.0.0.1',port=8000)
