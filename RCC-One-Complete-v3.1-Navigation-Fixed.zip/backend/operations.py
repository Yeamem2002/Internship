"""Construction operations prototype. All writes and their history commit together."""
import csv
import io
from contextlib import closing
from datetime import date
from typing import Literal
from pydantic import BaseModel, Field, ConfigDict
from fastapi import HTTPException, Request
from fastapi.responses import Response

KINDS = ('procurement', 'rfi', 'submittal', 'permit', 'qhse', 'variation')
FLOW = {'open': ['in_review'], 'in_review': ['approved', 'rejected'], 'rejected': ['open'], 'approved': ['closed'], 'closed': []}

class CleanModel(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

class Project(CleanModel):
    name: str = Field(min_length=3, max_length=160)
    sector: Literal['Education','Healthcare','Residential','Government','Private']
    location: str = Field(min_length=2, max_length=120)
    manager: str = Field(min_length=2, max_length=120)
    budget: float = Field(ge=0, le=1e12, allow_inf_nan=False)
    due: date
    progress: int = Field(ge=0, le=100)
    version: int = 1

class Item(CleanModel):
    project_id: int
    kind: Literal['procurement','rfi','submittal','permit','qhse','variation']
    title: str = Field(min_length=3, max_length=180)
    owner: str = Field(min_length=2, max_length=120)
    priority: Literal['normal','high','critical'] = 'normal'
    due: date
    amount: float = Field(default=0, ge=0, le=1e12, allow_inf_nan=False)
    detail: str = Field(default='', max_length=5000)

class Decision(CleanModel):
    status: Literal['open','in_review','approved','rejected','closed']
    note: str = Field(min_length=3, max_length=2000)
    version: int

class Daily(CleanModel):
    project_id: int
    day: date
    manpower: int = Field(ge=0, le=100000)
    hours: float = Field(ge=0, le=24, allow_inf_nan=False)
    work: str = Field(min_length=3, max_length=5000)
    blockers: str = Field(default='', max_length=3000)


def install_operations(app, database, current_user):
    with closing(database()) as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS ops_projects (
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, sector TEXT NOT NULL, location TEXT NOT NULL,
          manager TEXT NOT NULL, budget REAL NOT NULL, due TEXT NOT NULL, progress INTEGER NOT NULL,
          version INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS ops_items (
          id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL REFERENCES ops_projects(id), kind TEXT NOT NULL,
          title TEXT NOT NULL, owner TEXT NOT NULL, priority TEXT NOT NULL, due TEXT NOT NULL,
          amount REAL NOT NULL DEFAULT 0, detail TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open',
          version INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS ops_history (
          id INTEGER PRIMARY KEY, item_id INTEGER NOT NULL REFERENCES ops_items(id), actor TEXT NOT NULL,
          status TEXT NOT NULL, note TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS ops_daily (
          id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL REFERENCES ops_projects(id), day TEXT NOT NULL,
          manpower INTEGER NOT NULL, hours REAL NOT NULL, work TEXT NOT NULL, blockers TEXT NOT NULL,
          actor TEXT NOT NULL, UNIQUE(project_id,day));
        ''')
        c.commit()

    def user(request, write=False):
        u = current_user(request)
        if not u: raise HTTPException(401, 'Please sign in.')
        if write and u['role'] != 'authorized': raise HTTPException(403, 'This prototype requires Authorized access for changes.')
        return u

    def audit(c,u,action,entity,detail):
        c.execute('INSERT INTO activity(actor,action,entity,detail) VALUES(?,?,?,?)',(u['full_name'],action,entity,detail))

    def project_exists(c,pid):
        if not c.execute('SELECT id FROM ops_projects WHERE id=?',(pid,)).fetchone():
            raise HTTPException(404,'Project not found.')

    @app.get('/workspace/operations')
    def overview(request:Request):
        user(request)
        with closing(database()) as c:
            return {
                'projects':[dict(r) for r in c.execute('SELECT * FROM ops_projects ORDER BY id')],
                'items':[dict(r) for r in c.execute('SELECT i.*,p.name project FROM ops_items i JOIN ops_projects p ON p.id=i.project_id ORDER BY i.due,i.id')],
                'daily':[dict(r) for r in c.execute('SELECT d.*,p.name project FROM ops_daily d JOIN ops_projects p ON p.id=d.project_id ORDER BY d.day DESC,d.id DESC')],
                'history':[dict(r) for r in c.execute('SELECT * FROM ops_history ORDER BY id DESC')],
                'today':date.today().isoformat(), 'flow':FLOW,
                'demo':__import__('os').environ.get('RCC_DEMO')=='1'
            }

    @app.post('/workspace/operations/projects')
    def create_project(payload:Project, request:Request):
        u=user(request,True)
        with closing(database()) as c, c:
            pid=c.execute('INSERT INTO ops_projects(name,sector,location,manager,budget,due,progress) VALUES(?,?,?,?,?,?,?)',
                (payload.name.strip(),payload.sector,payload.location.strip(),payload.manager.strip(),payload.budget,str(payload.due),payload.progress)).lastrowid
            audit(c,u,'Project created',f'project/{pid}',payload.name)
            return {'id':pid}

    @app.put('/workspace/operations/projects/{pid}')
    def update_project(pid:int,payload:Project,request:Request):
        u=user(request,True)
        with closing(database()) as c, c:
            project_exists(c,pid)
            count=c.execute('UPDATE ops_projects SET name=?,sector=?,location=?,manager=?,budget=?,due=?,progress=?,version=version+1 WHERE id=? AND version=?',
                (payload.name.strip(),payload.sector,payload.location.strip(),payload.manager.strip(),payload.budget,str(payload.due),payload.progress,pid,payload.version)).rowcount
            if not count: raise HTTPException(409,'Project changed. Refresh and try again.')
            audit(c,u,'Project updated',f'project/{pid}',payload.name)
            return {'ok':True}

    @app.post('/workspace/operations/items')
    def create_item(payload:Item,request:Request):
        u=user(request,True)
        if payload.kind not in ('procurement','variation') and payload.amount:
            raise HTTPException(400,'Amounts apply only to procurement and variations.')
        with closing(database()) as c, c:
            project_exists(c,payload.project_id)
            ident=c.execute('INSERT INTO ops_items(project_id,kind,title,owner,priority,due,amount,detail) VALUES(?,?,?,?,?,?,?,?)',
                (payload.project_id,payload.kind,payload.title.strip(),payload.owner.strip(),payload.priority,str(payload.due),payload.amount,payload.detail.strip())).lastrowid
            c.execute('INSERT INTO ops_history(item_id,actor,status,note) VALUES(?,?,?,?)',(ident,u['full_name'],'open','Record created'))
            audit(c,u,'Register entry created',f'item/{ident}',payload.title)
            return {'id':ident}

    @app.patch('/workspace/operations/items/{ident}')
    def decide(ident:int,payload:Decision,request:Request):
        u=user(request,True)
        if len(payload.note.strip())<3: raise HTTPException(400,'Enter a decision or closure note.')
        with closing(database()) as c, c:
            r=c.execute('SELECT * FROM ops_items WHERE id=?',(ident,)).fetchone()
            if not r: raise HTTPException(404,'Record not found.')
            if payload.version != r['version']: raise HTTPException(409,'Record changed. Refresh before deciding.')
            if payload.status not in FLOW[r['status']]: raise HTTPException(400,'Invalid workflow transition.')
            count=c.execute('UPDATE ops_items SET status=?,version=version+1 WHERE id=? AND version=?',(payload.status,ident,payload.version)).rowcount
            if not count: raise HTTPException(409,'Record changed. Refresh before deciding.')
            c.execute('INSERT INTO ops_history(item_id,actor,status,note) VALUES(?,?,?,?)',(ident,u['full_name'],payload.status,payload.note.strip()))
            audit(c,u,'Workflow decision',f'item/{ident}',payload.status+': '+payload.note.strip())
            return {'ok':True}

    @app.post('/workspace/operations/daily')
    def create_daily(payload:Daily,request:Request):
        u=user(request,True)
        if payload.day>date.today(): raise HTTPException(400,'Daily reports cannot be future dated.')
        with closing(database()) as c, c:
            project_exists(c,payload.project_id)
            if c.execute('SELECT id FROM ops_daily WHERE project_id=? AND day=?',(payload.project_id,str(payload.day))).fetchone():
                raise HTTPException(409,'A daily report already exists for this project and date.')
            ident=c.execute('INSERT INTO ops_daily(project_id,day,manpower,hours,work,blockers,actor) VALUES(?,?,?,?,?,?,?)',
                (payload.project_id,str(payload.day),payload.manpower,payload.hours,payload.work.strip(),payload.blockers.strip(),u['full_name'])).lastrowid
            audit(c,u,'Site report filed',f'daily/{ident}',str(payload.day))
            return {'id':ident}

    @app.get('/workspace/operations/export')
    def export(request:Request):
        user(request)
        out=io.StringIO(); w=csv.writer(out)
        w.writerow(['Reference','Project','Type','Title','Owner','Priority','Due','Amount AED','Status'])
        with closing(database()) as c:
            for r in c.execute('SELECT i.id,p.name,i.kind,i.title,i.owner,i.priority,i.due,i.amount,i.status FROM ops_items i JOIN ops_projects p ON p.id=i.project_id ORDER BY i.id'):
                w.writerow([("'"+v if v.lstrip().startswith(('=','+','-','@')) else v) if isinstance(v,str) else v for v in r])
        return Response('\ufeff'+out.getvalue(),media_type='text/csv',headers={'Content-Disposition':'attachment; filename="RCC-register.csv"'})
