const statusEl = document.getElementById('authStatus');
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');

if (loginForm) {
  const params = new URLSearchParams(location.search);
  const requestedRole = params.get('role');
  const role = requestedRole === 'hr' ? 'hr' : 'authorized';
  document.getElementById('loginRole').value = role;
  document.getElementById('roleEyebrow').textContent = role === 'hr' ? 'HR ACCESS' : 'ADMIN ACCESS';
  document.getElementById('roleTitle').textContent = role === 'hr' ? 'HR Sign In' : 'Admin Sign In';
  document.getElementById('roleDescription').textContent = role === 'hr'
    ? 'Sign in to view and preview employee profiles.'
    : 'Sign in for project operations and the HR workspace.';
  document.getElementById('loginSubmit').textContent = role === 'hr' ? 'HR Sign In →' : 'Admin Sign In →';
  document.getElementById('signupPrompt').hidden = role !== 'hr';

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    statusEl.textContent = 'Signing in...';
    try {
    const r = await fetch('/auth/login', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        email: document.getElementById('email').value.trim(),
        password: document.getElementById('password').value,
        portal_role: role
      })
    });
    const d = await r.json();
    if (!r.ok) { statusEl.textContent = d.detail || 'Could not sign in.'; return; }
    location.href = '/app/operations.html';
    } catch(error) { statusEl.textContent = 'Could not connect to the local server. Check that it is running.'; }
  });
}

if (signupForm) signupForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  statusEl.textContent = 'Creating account...';
  try {
  const r = await fetch('/auth/signup', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body:JSON.stringify({
      full_name:document.getElementById('fullName').value.trim(),
      email:document.getElementById('email').value.trim(),
      password:document.getElementById('password').value
    })
  });
  const d = await r.json();
  if (!r.ok) { statusEl.textContent=d.detail||'Could not create account.'; return; }
  statusEl.textContent=d.message;
  setTimeout(()=>location.href='role-login.html?role=hr',700);
  } catch(error) { statusEl.textContent = 'Could not connect to the local server.'; }
});
