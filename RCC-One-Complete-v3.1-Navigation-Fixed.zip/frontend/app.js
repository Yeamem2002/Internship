const selectedProfileFromUrl = new URLSearchParams(location.search).get("profile_id");
if(selectedProfileFromUrl) localStorage.setItem("documentAutofillProfileId", selectedProfileFromUrl);
let extractedData = null;
let selectedDocumentType = null;
let documentPreviewUrl = null;


// =====================================================
// ELEMENTS
// =====================================================

const profileStatus =
    document.getElementById("profileStatus");

const profileMessage =
    document.getElementById("profileMessage");

const newProfileButton =
    document.getElementById("newProfileButton");

const autofillButton =
    document.getElementById("autofillButton");

const emiratesStatus =
    document.getElementById("emiratesStatus");

const emiratesFile =
    document.getElementById("emiratesFile");

const cvStatus =
    document.getElementById("cvStatus");

const cvFile =
    document.getElementById("cvFile");


// =====================================================
// UPLOAD MODAL
// =====================================================

const uploadModal =
    document.getElementById("uploadModal");

const uploadModalTitle =
    document.getElementById("uploadModalTitle");

const selectedDocumentTypeElement =
    document.getElementById("selectedDocumentType");

const fileInput =
    document.getElementById("fileInput");

const selectedFileName =
    document.getElementById("selectedFileName");

const uploadStatus =
    document.getElementById("uploadStatus");

const uploadButton =
    document.getElementById("uploadButton");

const closeUploadModal =
    document.getElementById("closeUploadModal");

const cancelUploadButton =
    document.getElementById("cancelUploadButton");


// =====================================================
// REVIEW MODAL
// =====================================================

const reviewModal =
    document.getElementById("reviewModal");

const reviewTitle =
    document.getElementById("reviewTitle");

const reviewFields =
    document.getElementById("reviewFields");

const documentPreview =
    document.getElementById("documentPreview");

const confirmStatus =
    document.getElementById("confirmStatus");

const confirmButton =
    document.getElementById("confirmButton");

const closeReviewModal =
    document.getElementById("closeReviewModal");

const cancelReviewButton =
    document.getElementById("cancelReviewButton");


// =====================================================
// PROFILE ID
// =====================================================

function getProfileId() {
    return localStorage.getItem(
        "documentAutofillProfileId"
    );
}


function saveProfileId(profileId) {
    localStorage.setItem(
        "documentAutofillProfileId",
        profileId
    );
}


function clearProfileId() {
    localStorage.removeItem(
        "documentAutofillProfileId"
    );
}


// =====================================================
// CREATE PROFILE
// =====================================================

async function createProfile() {

    if (profileStatus) {
        profileStatus.textContent = "Creating profile...";
    }
    if (profileMessage) {
        profileMessage.textContent = "Creating profile...";
    }

    try {

        const response =
            await fetch(
                "/profiles",
                {
                    method: "POST"
                }
            );

        const data =
            await response.json();

        if (!response.ok) {

            if (profileStatus) {
                profileStatus.textContent = data.detail || "Could not create profile.";
            }
            if (profileMessage) {
                profileMessage.textContent = data.detail || "Could not create profile.";
            }

            return false;
        }

        saveProfileId(
            data.profile_id
        );

        if (profileStatus) {
            profileStatus.textContent = "Active profile";
        }

        profileMessage.textContent =
            "Profile created. Add your documents.";

        await loadProfile();

        return true;
    }
    catch (error) {

        console.error(
            "Create profile error:",
            error
        );

        if (profileStatus) {
            profileStatus.textContent = "Connection error";
        }
        if (profileMessage) {
            profileMessage.textContent = "Could not create profile.";
        }

        return false;
    }
}


// =====================================================
// RESET DOCUMENT ROWS
// =====================================================

function resetDocumentRows() {

    emiratesStatus.className =
        "document-status missing";

    emiratesStatus.innerHTML =
        "<span></span>Missing";

    emiratesFile.textContent =
        "—";

    cvStatus.className =
        "document-status missing";

    cvStatus.innerHTML =
        "<span></span>Missing";

    cvFile.textContent =
        "—";

    document
        .querySelectorAll(".row-button")
        .forEach(button => {

            button.textContent =
                "Upload";
        });
}


// =====================================================
// UPDATE DOCUMENT ROW
// =====================================================

function markDocumentAdded(
    type,
    filename
) {

    let statusElement;
    let fileElement;

    if (type === "Emirates ID") {

        statusElement =
            emiratesStatus;

        fileElement =
            emiratesFile;
    }
    else if (type === "CV") {

        statusElement =
            cvStatus;

        fileElement =
            cvFile;
    }
    else {
        return;
    }

    statusElement.className =
        "document-status active";

    statusElement.innerHTML =
        "<span></span>Active";

    fileElement.textContent =
        filename || "Document added";

    const buttonType =
        type === "Emirates ID"
            ? "emirates_id"
            : "cv";

    const button =
        document.querySelector(
            `[data-document="${buttonType}"]`
        );

    if (button) {
        button.textContent =
            "Replace";
    }
}


// =====================================================
// LOAD PROFILE
// =====================================================

async function loadProfile() {

    const profileId =
        getProfileId();

    resetDocumentRows();

    if (!profileId) {

        if (profileStatus) profileStatus.textContent = "No active profile";

        profileMessage.textContent =
            "Start a profile and add your documents.";

        return;
    }

    try {

        const response =
            await fetch(
                `/profiles/${
                    encodeURIComponent(profileId)
                }/summary`
            );

        const data =
            await response.json();

        if (!response.ok) {

            clearProfileId();

            profileStatus.textContent =
                "No active profile";

            profileMessage.textContent =
                "Start a profile and add your documents.";

            return;
        }

        console.log(
            "Profile summary:",
            data
        );

        if (profileStatus) {
            profileStatus.textContent = "Active profile";
        }

        const allDocuments =
            data.documents || [];

        const documents = [
            ...new Map(
                allDocuments.map(document => [
                    document.document_type,
                    document
                ])
            ).values()
        ];

        documents.forEach(
            item => {

                markDocumentAdded(
                    item.document_type,
                    item.filename
                );
            }
        );

        if (documents.length === 0) {

            profileMessage.textContent =
                "Profile ready. Add your first document.";
        }
        else if (documents.length === 1) {

            profileMessage.textContent =
                "1 document added. You can add another.";
        }
        else {

            profileMessage.textContent =
                `${documents.length} documents added. ` +
                "Your profile is ready for autofill.";
        }
    }
    catch (error) {

        console.error(
            "Load profile error:",
            error
        );

        if (profileStatus) profileStatus.textContent = "Could not load profile";
    }
}


// =====================================================
// OPEN UPLOAD MODAL
// =====================================================

async function openUploadModal(type) {

    let profileId =
        getProfileId();

    if (!profileId) {

        const created =
            await createProfile();

        if (!created) {
            return;
        }

        profileId =
            getProfileId();
    }

    selectedDocumentType =
        type;

    extractedData =
        null;

    clearDocumentPreview();

    fileInput.value =
        "";

    selectedFileName.textContent =
        "";

    uploadStatus.textContent =
        "";

    if (type === "emirates_id") {

        uploadModalTitle.textContent =
            "Emirates ID";

        selectedDocumentTypeElement.textContent =
            "Emirates ID";
    }
    else {

        uploadModalTitle.textContent =
            "CV / Resume";

        selectedDocumentTypeElement.textContent =
            "CV / Resume";
    }

    uploadModal.classList.remove(
        "hidden"
    );
}


// =====================================================
// CLOSE UPLOAD MODAL
// =====================================================

function hideUploadModal() {

    uploadModal.classList.add(
        "hidden"
    );
}


// =====================================================
// FILE SELECTED
// =====================================================

fileInput.addEventListener(
    "change",
    function() {

        const file =
            fileInput.files[0];

        selectedFileName.textContent =
            file
                ? file.name
                : "";
    }
);


// =====================================================
// UPLOAD / EXTRACT
// =====================================================

async function uploadDocument() {

    const file =
        fileInput.files[0];

    if (!file) {

        uploadStatus.textContent =
            "Please choose a document first.";

        return;
    }

    if (!selectedDocumentType) {

        uploadStatus.textContent =
            "Document type is missing.";

        return;
    }

    const formData =
        new FormData();

    formData.append(
        "file",
        file
    );

    formData.append(
        "expected_type",
        selectedDocumentType
    );

    uploadStatus.textContent =
        "Reading document...";

    uploadButton.disabled =
        true;

    try {

        const response =
            await fetch(
                "/upload",
                {
                    method: "POST",
                    body: formData
                }
            );

        const data =
            await response.json();

        if (!response.ok) {

            uploadStatus.textContent =
                data.detail ||
                "Could not read document.";

            return;
        }

        extractedData =
            data;

        console.log(
            "Extracted data:",
            data
        );

        /*
         * Build the local preview BEFORE changing/resetting
         * the file input. The browser still has the exact
         * File selected by the user.
         */
        displayDocumentPreview(
            file
        );

        hideUploadModal();

        displayReview(
            data
        );
    }
    catch (error) {

        console.error(
            "Upload error:",
            error
        );

        uploadStatus.textContent =
            "Could not connect to server.";
    }
    finally {

        uploadButton.disabled =
            false;
    }
}


// =====================================================
// DOCUMENT PREVIEW
// =====================================================

function clearDocumentPreview() {

    if (documentPreviewUrl) {

        URL.revokeObjectURL(
            documentPreviewUrl
        );

        documentPreviewUrl =
            null;
    }

    if (documentPreview) {

        documentPreview.innerHTML =
            "<span>Document preview</span>";
    }
}


function displayDocumentPreview(file) {

    clearDocumentPreview();

    if (!file) {

        documentPreview.textContent =
            "Preview unavailable.";

        return;
    }

    documentPreviewUrl =
        URL.createObjectURL(
            file
        );

    documentPreview.innerHTML =
        "";

    if (
        file.type === "image/jpeg" ||
        file.type === "image/png" ||
        /\.(jpe?g|png)$/i.test(file.name)
    ) {

        const image =
            document.createElement(
                "img"
            );

        image.src =
            documentPreviewUrl;

        image.alt =
            "Uploaded document";

        documentPreview.appendChild(
            image
        );

        return;
    }

    if (
        file.type === "application/pdf" ||
        /\.pdf$/i.test(file.name)
    ) {

        const frame =
            document.createElement(
                "iframe"
            );

        frame.src =
            documentPreviewUrl;

        frame.title =
            "Uploaded PDF";

        documentPreview.appendChild(
            frame
        );

        return;
    }

    documentPreview.textContent =
        "Preview unavailable for this file type.";
}


// =====================================================
// REVIEW FIELD
// =====================================================

function addReviewField(
    label,
    key,
    value,
    multiline = false
) {

    const wrapper =
        document.createElement(
            "div"
        );

    wrapper.className =
        "review-field";

    const labelElement =
        document.createElement(
            "label"
        );

    labelElement.textContent =
        label;

    let input;

    if (multiline) {

        input =
            document.createElement(
                "textarea"
            );

        input.rows =
            4;
    }
    else {

        input =
            document.createElement(
                "input"
            );

        input.type =
            "text";
    }

    input.id =
        `review_${key}`;

    input.value =
        value || "";

    wrapper.appendChild(
        labelElement
    );

    wrapper.appendChild(
        input
    );

    reviewFields.appendChild(
        wrapper
    );
}


// =====================================================
// DISPLAY REVIEW
// =====================================================

function displayReview(data) {

    reviewFields.innerHTML =
        "";

    confirmStatus.textContent =
        "";

    reviewTitle.textContent =
        data.document_type;

    if (
        data.document_type ===
        "Emirates ID"
    ) {

        addReviewField(
            "Full Name",
            "name",
            data.name
        );

        addReviewField(
            "Emirates ID Number",
            "document_number",
            data.document_number
        );

        addReviewField(
            "Date of Birth",
            "date_of_birth",
            data.date_of_birth
        );

        addReviewField(
            "Nationality",
            "nationality",
            data.nationality
        );

        addReviewField(
            "Issue Date",
            "issue_date",
            data.issue_date
        );

        addReviewField(
            "Expiry Date",
            "expiry_date",
            data.expiry_date
        );
    }

    if (
        data.document_type ===
        "CV"
    ) {

        addReviewField(
            "Full Name",
            "name",
            data.name
        );

        addReviewField(
            "Email",
            "email",
            data.email
        );

        addReviewField(
            "Phone Number",
            "phone_number",
            data.phone_number
        );

        addReviewField(
            "Education",
            "education",
            data.education,
            true
        );

        addReviewField(
            "Skills",
            "skills",
            data.skills,
            true
        );

        addReviewField(
            "Experience",
            "experience",
            data.experience,
            true
        );

        addReviewField(
            "Projects",
            "projects",
            data.projects,
            true
        );
    }

    reviewModal.classList.remove(
        "hidden"
    );
}


// =====================================================
// REVIEW VALUE
// =====================================================

function getReviewValue(key) {

    const element =
        document.getElementById(
            `review_${key}`
        );

    if (!element) {
        return null;
    }

    const value =
        element.value.trim();

    return value === ""
        ? null
        : value;
}


// =====================================================
// CLOSE REVIEW MODAL
// =====================================================

function hideReviewModal() {

    reviewModal.classList.add(
        "hidden"
    );

    /*
     * The preview URL is temporary and only needed while
     * the review window is open.
     */
    clearDocumentPreview();
}


// =====================================================
// CONFIRM
// =====================================================

async function confirmDocument() {

    if (!extractedData) {

        confirmStatus.textContent =
            "No document to confirm.";

        return;
    }

    const profileId =
        getProfileId();

    if (!profileId) {

        confirmStatus.textContent =
            "No active profile.";

        return;
    }

    const confirmedData = {

        ...extractedData,

        profile_id:
            profileId,

        name:
            getReviewValue("name"),

        document_number:
            getReviewValue("document_number"),

        date_of_birth:
            getReviewValue("date_of_birth"),

        nationality:
            getReviewValue("nationality"),

        issue_date:
            getReviewValue("issue_date"),

        expiry_date:
            getReviewValue("expiry_date"),

        email:
            getReviewValue("email"),

        phone_number:
            getReviewValue("phone_number"),

        education:
            getReviewValue("education"),

        skills:
            getReviewValue("skills"),

        experience:
            getReviewValue("experience"),

        projects:
            getReviewValue("projects")
    };

    confirmStatus.textContent =
        "Saving confirmed information...";

    confirmButton.disabled =
        true;

    try {

        const response =
            await fetch(
                "/confirm",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify(
                            confirmedData
                        )
                }
            );

        const data =
            await response.json();

        if (!response.ok) {

            confirmStatus.textContent =
                data.detail ||
                "Could not save document.";

            return;
        }

        console.log(
            "Confirmed:",
            data
        );

        hideReviewModal();

        extractedData =
            null;

        await loadProfile();
    }
    catch (error) {

        console.error(
            "Confirm error:",
            error
        );

        confirmStatus.textContent =
            "Could not connect to server.";
    }
    finally {

        confirmButton.disabled =
            false;
    }
}


// =====================================================
// AUTOFILL
// =====================================================

function openAutofillApplication() {

    const profileId =
        getProfileId();

    if (!profileId) {

        alert(
            "Add a profile first."
        );

        return;
    }

    window.location.href =
        `/app/form.html?profile_id=${
            encodeURIComponent(profileId)
        }`;
}


// =====================================================
// DOCUMENT BUTTONS
// =====================================================

document
    .querySelectorAll(".row-button")
    .forEach(button => {

        button.addEventListener(
            "click",
            function() {

                openUploadModal(
                    button.dataset.document
                );
            }
        );
    });


// =====================================================
// MODAL EVENTS
// =====================================================

closeUploadModal.addEventListener(
    "click",
    hideUploadModal
);

cancelUploadButton.addEventListener(
    "click",
    hideUploadModal
);

closeReviewModal.addEventListener(
    "click",
    hideReviewModal
);

cancelReviewButton.addEventListener(
    "click",
    hideReviewModal
);


// =====================================================
// MAIN EVENTS
// =====================================================

newProfileButton.addEventListener(
    "click",
    createProfile
);

uploadButton.addEventListener(
    "click",
    uploadDocument
);

confirmButton.addEventListener(
    "click",
    confirmDocument
);

autofillButton.addEventListener(
    "click",
    openAutofillApplication
);


// =====================================================
// CLOSE MODAL BY CLICKING BACKDROP
// =====================================================

uploadModal.addEventListener(
    "click",
    function(event) {

        if (event.target === uploadModal) {
            hideUploadModal();
        }
    }
);

reviewModal.addEventListener(
    "click",
    function(event) {

        if (event.target === reviewModal) {
            hideReviewModal();
        }
    }
);


// =====================================================
// PROFILE SEARCH
// =====================================================

const profileSearchInput = document.getElementById("profileSearchInput");
const profileSearchResults = document.getElementById("profileSearchResults");
const profileSearchButton = document.getElementById("profileSearchButton");
const editProfileButton = document.getElementById("editProfileButton");
const editProfileModal = document.getElementById("editProfileModal");
const closeEditProfileModal = document.getElementById("closeEditProfileModal");
const cancelEditProfileButton = document.getElementById("cancelEditProfileButton");
const saveEditProfileButton = document.getElementById("saveEditProfileButton");
const editProfileFields = document.getElementById("editProfileFields");
const editProfileStatus = document.getElementById("editProfileStatus");

let searchTimer = null;

function hideSearchResults() {
    profileSearchResults.classList.add("hidden");
    profileSearchResults.innerHTML = "";
}

function profileSubtitle(profile) {
    const parts = [];
    if (profile.email) parts.push(profile.email);
    if (profile.document_number) parts.push(profile.document_number);
    return parts.join(" • ") || "Profile";
}

async function searchProfiles() {
    const query = profileSearchInput.value.trim();
    if (!query) {
        hideSearchResults();
        return;
    }

    try {
        const response = await fetch(`/profiles/search?q=${encodeURIComponent(query)}`);
        const profiles = await response.json();
        if (!response.ok) throw new Error(profiles.detail || "Search failed");

        profileSearchResults.innerHTML = "";
        profileSearchResults.classList.remove("hidden");

        if (!profiles.length) {
            profileSearchResults.innerHTML = '<div class="search-empty">No matching profiles found.</div>';
            return;
        }

        profiles.forEach(profile => {
            const row = document.createElement("div");
            row.className = "profile-result-row";

            const button = document.createElement("button");
            button.type = "button";
            button.className = "profile-search-result";

            const name = document.createElement("strong");
            name.textContent = profile.name || "Unnamed profile";
            const details = document.createElement("span");
            details.textContent = profileSubtitle(profile);
            button.append(name, details);

            button.addEventListener("click", async () => {
                saveProfileId(profile.id);
                profileSearchInput.value = profile.name || "";
                hideSearchResults();
                await loadProfile();
                profileMessage.textContent = `Loaded profile: ${profile.name || "Unnamed profile"}.`;
            });

            const editButton = document.createElement("button");
            editButton.type = "button";
            editButton.className = "profile-result-edit";
            editButton.textContent = "Edit";
            editButton.addEventListener("click", async (event) => {
                event.stopPropagation();
                saveProfileId(profile.id);
                profileSearchInput.value = profile.name || "";
                hideSearchResults();
                await loadProfile();
                await openEditProfile();
            });

            row.append(button, editButton);
            profileSearchResults.appendChild(row);
        });
    } catch (error) {
        console.error("Profile search error:", error);
        profileSearchResults.classList.remove("hidden");
        profileSearchResults.innerHTML = '<div class="search-empty">Could not search profiles.</div>';
    }
}

profileSearchInput.addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(searchProfiles, 160);
});

profileSearchButton.addEventListener("click", searchProfiles);

profileSearchInput.addEventListener("keydown", event => {
    if (event.key === "Enter") {
        event.preventDefault();
        clearTimeout(searchTimer);
        searchProfiles();
    }
});

profileSearchInput.addEventListener("focus", () => {
    if (profileSearchInput.value.trim()) searchProfiles();
});

document.addEventListener("click", event => {
    if (!event.target.closest(".profile-search-wrap")) hideSearchResults();
});


// =====================================================
// EDIT PROFILE
// =====================================================

const PROFILE_EDIT_FIELDS = [
    ["name", "Full Name", "text", false],
    ["date_of_birth", "Date of Birth", "text", false],
    ["nationality", "Nationality", "text", false],
    ["email", "Email", "email", false],
    ["phone_number", "Phone Number", "text", false],
    ["document_number", "Emirates ID", "text", false],
    ["issue_date", "Issue Date", "text", false],
    ["expiry_date", "Expiry Date", "text", false],
    ["education", "Education", "textarea", true],
    ["skills", "Skills", "textarea", true],
    ["experience", "Experience", "textarea", true],
    ["projects", "Projects", "textarea", true]
];

function renderEditFields(profile) {
    editProfileFields.innerHTML = "";

    PROFILE_EDIT_FIELDS.forEach(([key, label, type, full]) => {
        const wrapper = document.createElement("div");
        wrapper.className = `edit-field${full ? " full" : ""}`;

        const labelElement = document.createElement("label");
        labelElement.htmlFor = `edit_${key}`;
        labelElement.textContent = label;

        const input = type === "textarea"
            ? document.createElement("textarea")
            : document.createElement("input");

        if (type !== "textarea") input.type = type;
        input.id = `edit_${key}`;
        input.dataset.field = key;
        input.value = profile[key] || "";

        wrapper.append(labelElement, input);
        editProfileFields.appendChild(wrapper);
    });
}

async function openEditProfile() {
    const profileId = getProfileId();
    if (!profileId) {
        alert("Search for or create a profile first.");
        return;
    }

    editProfileStatus.textContent = "Loading profile...";
    editProfileModal.classList.remove("hidden");

    try {
        const response = await fetch(`/profiles/${encodeURIComponent(profileId)}`);
        const profile = await response.json();
        if (!response.ok) {
            editProfileStatus.textContent = profile.detail || "Could not load profile.";
            return;
        }
        renderEditFields(profile);
        editProfileStatus.textContent = "";
    } catch (error) {
        console.error("Edit profile load error:", error);
        editProfileStatus.textContent = "Could not connect to server.";
    }
}

function closeEditProfile() {
    editProfileModal.classList.add("hidden");
    editProfileStatus.textContent = "";
}

async function saveProfileChanges() {
    const profileId = getProfileId();
    if (!profileId) return;

    const payload = {};
    editProfileFields.querySelectorAll("[data-field]").forEach(input => {
        payload[input.dataset.field] = input.value.trim() || null;
    });

    saveEditProfileButton.disabled = true;
    saveEditProfileButton.textContent = "Saving...";
    editProfileStatus.textContent = "Saving changes...";

    try {
        const response = await fetch(`/profiles/${encodeURIComponent(profileId)}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        const data = await response.json();

        if (!response.ok) {
            editProfileStatus.textContent = data.detail || "Could not update profile.";
            return;
        }

        profileSearchInput.value = data.profile?.name || "";
        await loadProfile();

        if (data.excel_saved === false) {
            editProfileStatus.textContent = "Profile updated, but Excel is open. Close Excel and sync it later.";
        } else {
            editProfileStatus.textContent = "Profile and Excel updated successfully.";
            setTimeout(closeEditProfile, 650);
        }
    } catch (error) {
        console.error("Profile update error:", error);
        editProfileStatus.textContent = "Could not connect to server.";
    } finally {
        saveEditProfileButton.disabled = false;
        saveEditProfileButton.textContent = "Save Changes";
    }
}

if (editProfileButton) editProfileButton.addEventListener("click", openEditProfile);
closeEditProfileModal.addEventListener("click", closeEditProfile);
cancelEditProfileButton.addEventListener("click", closeEditProfile);
saveEditProfileButton.addEventListener("click", saveProfileChanges);
editProfileModal.addEventListener("click", event => {
    if (event.target === editProfileModal) closeEditProfile();
});


// =====================================================
// INITIAL LOAD
// =====================================================

loadProfile();


// =====================================================
// MANAGE PROFILES PAGE
// =====================================================
const manageProfilesButton = document.getElementById("manageProfilesButton");
if (manageProfilesButton) {
    manageProfilesButton.addEventListener("click", () => {
        window.location.href = "/app/profiles.html";
    });
}

// Drop a file onto the upload area; normal selection remains keyboard accessible.
const dropBox=document.querySelector('.upload-box');
if(dropBox){
 ['dragenter','dragover'].forEach(name=>dropBox.addEventListener(name,e=>{e.preventDefault();dropBox.classList.add('dragging');}));
 ['dragleave','drop'].forEach(name=>dropBox.addEventListener(name,e=>{e.preventDefault();dropBox.classList.remove('dragging');}));
 dropBox.addEventListener('drop',e=>{if(e.dataTransfer.files.length){fileInput.files=e.dataTransfer.files;fileInput.dispatchEvent(new Event('change'));}});
}
