"""Construction regression checks. Reuses the isolated HR test database."""
import unittest
import test_workflow
from fastapi.testclient import TestClient
from backend import main
from datetime import date,timedelta

class Operations(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with main.get_database() as c:
            for ident,role in [('opsadmin','authorized'),('opshr','hr')]:
                c.execute('INSERT INTO users(id,full_name,email,password_hash,role) VALUES(?,?,?,?,?)',(ident,ident,ident+'@example.test',main.hash_password('Prototype123!'),role))
        cls.admin=TestClient(main.app);cls.hr=TestClient(main.app)
        for client,ident in [(cls.admin,'opsadmin'),(cls.hr,'opshr')]:
            assert client.post('/auth/login',json={'email':ident+'@example.test','password':'Prototype123!'}).status_code==200

    def test_operations_end_to_end(self):
        base='/workspace/operations'
        self.assertEqual(TestClient(main.app).get(base).status_code,401)
        p={'name':'Synthetic school','sector':'Education','location':'Demo site','manager':'Demo manager','budget':100000,'due':str(date.today()),'progress':20}
        self.assertEqual(self.hr.post(base+'/projects',json=p).status_code,403)
        r=self.admin.post(base+'/projects',json=p);self.assertEqual(r.status_code,200,r.text);pid=r.json()['id']
        self.assertEqual(self.admin.put(base+f'/projects/{pid}',json={**p,'progress':101}).status_code,422)
        self.assertEqual(self.admin.put(base+f'/projects/{pid}',json={**p,'progress':40,'version':1}).status_code,200)
        self.assertEqual(self.admin.put(base+f'/projects/{pid}',json={**p,'version':1}).status_code,409)
        item={'project_id':pid,'kind':'procurement','title':'=Test material','owner':'Demo buyer','priority':'high','due':str(date.today()),'amount':5000,'detail':'Testing'}
        self.assertEqual(self.admin.post(base+'/items',json={**item,'project_id':99999}).status_code,404)
        self.assertEqual(self.admin.post(base+'/items',json={**item,'kind':'rfi'}).status_code,400)
        r=self.admin.post(base+'/items',json=item);self.assertEqual(r.status_code,200,r.text);iid=r.json()['id'];url=base+f'/items/{iid}'
        self.assertEqual(self.hr.patch(url,json={'status':'in_review','note':'Review','version':1}).status_code,403)
        self.assertEqual(self.admin.patch(url,json={'status':'approved','note':'Skipping','version':1}).status_code,400)
        self.assertEqual(self.admin.patch(url,json={'status':'in_review','note':'   ','version':1}).status_code,422)
        for version,status in enumerate(['in_review','rejected','open','in_review','approved','closed'],1):
            r=self.admin.patch(url,json={'status':status,'note':'Reviewed evidence','version':version});self.assertEqual(r.status_code,200,r.text)
        self.assertEqual(self.admin.patch(url,json={'status':'closed','note':'Stale action','version':6}).status_code,409)
        overview=self.admin.get(base).json();row=next(i for i in overview['items'] if i['id']==iid)
        self.assertEqual(row['status'],'closed');self.assertEqual(row['version'],7)
        self.assertEqual(len([h for h in overview['history'] if h['item_id']==iid]),7)
        daily={'project_id':pid,'day':str(date.today()),'manpower':20,'hours':8,'work':'Foundation completed','blockers':''}
        self.assertEqual(self.admin.post(base+'/daily',json=daily).status_code,200)
        self.assertEqual(self.admin.post(base+'/daily',json=daily).status_code,409)
        self.assertEqual(self.admin.post(base+'/daily',json={**daily,'day':str(date.today()+timedelta(days=1))}).status_code,400)
        self.assertIn("'=Test material",self.admin.get(base+'/export').text)
        self.assertEqual(self.hr.get(base).status_code,200)
