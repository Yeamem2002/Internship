"""Start the local-only RCC prototype from any working directory."""
from pathlib import Path
import os
import uvicorn

if __name__ == '__main__':
    os.chdir(Path(__file__).resolve().parent)
    print('RCC prototype: http://127.0.0.1:8000/app/operations.html')
    uvicorn.run('backend.main:app', host='127.0.0.1', port=8000)
