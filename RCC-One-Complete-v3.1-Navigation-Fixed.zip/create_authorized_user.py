"""Create a local account without starting the server. Existing accounts are preserved."""
import getpass
import hashlib
import secrets
import sqlite3
import uuid
import os
from pathlib import Path


def main():
    db = Path(os.environ.get('DOCUMENT_DB', str(Path(__file__).resolve().parent / 'document_autofill.db')))
    name = input('Full name: ').strip()
    email = input('Email: ').strip().lower()
    password = getpass.getpass('Password (8+ characters): ')
    if not name or '@' not in email or len(password) < 8:
        raise SystemExit('Enter a full name, email and a password of at least 8 characters.')
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 200000)
    with sqlite3.connect(db) as c:
        c.execute("CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, full_name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('hr','authorized')), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
        try:
            c.execute('INSERT INTO users(id,full_name,email,password_hash,role) VALUES(?,?,?,?,?)',
                      (str(uuid.uuid4()), name, email, f'{salt.hex()}:{digest.hex()}', 'authorized'))
        except sqlite3.IntegrityError:
            raise SystemExit('That email already has an account. Use a different email.')
    print('Authorized account created. Start the server and sign in through Admin access.')

if __name__ == '__main__':
    main()
